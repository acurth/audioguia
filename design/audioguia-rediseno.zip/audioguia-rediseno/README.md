# audioguia.io — rediseño, paquete para implementar

Este paquete contiene las 19 pantallas del rediseño, listas para abrir en el navegador,
más las instrucciones para llevarlas al código de la PWA SvelteKit.

Si estás leyendo esto como agente de código (Codex, Claude Code), empezá por
**`IMPLEMENTACION.md`**: ahí está el spec, las reglas de comportamiento y lo que
todavía falta del lado de los datos. Este archivo solo describe qué hay en cada carpeta.

## Qué hay acá

```
audioguia-rediseno/
├── README.md              este archivo
├── IMPLEMENTACION.md      el spec: breakpoints, componentes, comportamiento, pendientes
├── tokens.css             la paleta y la escala de espaciado como variables CSS
├── indice.html            abrilo primero: lista las 19 pantallas con links
├── pantallas/
│   ├── vertical/          9 pantallas, 430 x 932 (teléfono parado)
│   ├── horizontal/        8 pantallas, 932 x 430 (teléfono acostado)
│   └── tableta/           2 pantallas, 1194 x 834
├── assets/                las 10 imágenes que usan las pantallas
└── generadores/           los dos scripts Python que produjeron todo
```

## Cómo mirar las pantallas

Abrí `indice.html` en el navegador. Cada pantalla es un HTML autónomo, sin build y sin
dependencias, salvo la tipografía Lato que carga de Google Fonts. Los links internos entre
pantallas funcionan, así que podés navegar el prototipo.

Las pantallas tienen el tamaño fijo del dispositivo, en píxeles. Son maquetas, no la app
responsive: el objetivo es que se vea exactamente qué va en cada lugar y con qué medidas.
Cómo pasar de estas tres maquetas a un layout responsive está en `IMPLEMENTACION.md`.

## Sobre los estilos inline

Todo el CSS está inline en los elementos. Es a propósito: estas pantallas salieron de un
canvas de diseño donde el panel de propiedades edita justamente esos estilos. **No las
copies tal cual al código.** Usá `tokens.css` y armá componentes Svelte de verdad. Las
maquetas son la referencia visual y la fuente de las medidas, no el código de producción.

## Los generadores

`generadores/gen_ag.py` produce las pantallas verticales y `gen_ag_h.py` las horizontales
y de tableta, importando del primero. Están incluidos por si querés regenerar una pantalla
con un cambio, pero no hacen falta para implementar. Los componentes compartidos viven ahí
como funciones, y sirven para ver qué se repite entre pantallas:
`nav`, `nav_inverted`, `rail`, `map_panel`, `foto_map`, `trail_progress`,
`current_point_card`, `foto_toggle`, `scrubber`, `transport`, `eyebrow`, `ic`.

## Advertencia sobre el mapa

`assets/mapa-base-PROVISORIO.jpg` es una captura de pantalla usada solo para la maqueta.
**No se puede publicar.** El reemplazo y los motivos están en `IMPLEMENTACION.md`.
