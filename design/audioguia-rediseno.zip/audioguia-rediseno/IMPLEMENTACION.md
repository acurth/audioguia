# audioguia.io — spec de implementación

Para quien lleve estas maquetas al código de la PWA SvelteKit.
Las maquetas están en `pantallas/`, los colores y espaciados en `tokens.css`.

**Convención del proyecto: los comentarios de código se escriben en inglés.**
Los textos de interfaz van en español rioplatense, con voseo.

---

## 1. Para quién es esta interfaz

Esto decide casi todas las decisiones visuales que siguen, así que va primero.

La audioguía la usan dos personas caminando juntas. La persona con discapacidad visual
escucha el relato. **Toda la parte visual es para quien la acompaña.** Nadie recorre
estos senderos solo: el terreno tiene muchas imperfecciones y los puntos que disparan
audio son pocos y están lejos entre sí.

Consecuencias prácticas:

- La foto de cada punto existe para que el acompañante identifique el objeto del que
  habla el relato: un agujero en un tronco, un nudo que en realidad es un llao llao.
- El audio probablemente salga por el parlante del teléfono, así que lo escuchan los dos.
- Los contrastes son más exigentes que el mínimo, porque también la usa gente con baja visión.
- Los targets táctiles son de 44 px como piso, y se bajan a 38 solo en horizontal, donde
  la altura escasea.

Pendiente, todavía sin diseñar: indicadores sonoros que acompañen el recorrido.

---

## 2. Los tres puntos de quiebre

No son dos, son tres. La tableta no se resuelve estirando el horizontal del teléfono.

| Caso | Ancho | Navegación | Layout |
|---|---|---|---|
| Teléfono parado | hasta 599 px | barra fija abajo, 4 pestañas | una columna |
| Teléfono acostado | 600 a 839 px | riel vertical de 76 px a la izquierda | dos columnas |
| Tableta | desde 840 px | riel vertical de 92 px a la izquierda | maestro-detalle |

En horizontal el recurso escaso es **la altura**: quedan unos 380 px útiles. Por eso la
barra de 4 pestañas se convierte en riel lateral, y cada pantalla se parte en dos columnas.

En tableta lo que pide el ancho es maestro-detalle: la lista a la izquierda y el recorrido
elegido a la derecha, las dos cosas a la vez y sin navegar.

**Falta todavía la tableta en vertical (iPad parado, 820 x 1180).** Mi recomendación:
volver a la estructura vertical del teléfono, escalada, con la barra de pestañas abajo,
la lista de recorridos en dos columnas, y el texto con un ancho máximo de unos 680 px
centrado para que los párrafos no se estiren.

---

## 3. La navegación

Cuatro secciones fijas: **Inicio · Explorar · Offline · Cuenta**.

- `Cerca mío` dejó de ser una pantalla: ahora es un criterio de orden dentro de Explorar.
- La pantalla aparte de lista de puntos se dio de baja: los nombres van sobre el mapa.
- `Cuenta` por ahora es solo el acceso. Las pantallas de login, perfil y editor no están
  diseñadas todavía.

Sobre, Detalle y Recorrido no son pestañas, así que llevan botón de volver. Las cuatro
pestañas no lo llevan: el riel o la barra ya son la navegación.

En la pantalla de recorrido en curso la barra inferior va invertida, sobre `--ag-navy-nav`
(#0B2033), para que el verde activo dé 6,4:1 de contraste.

---

## 4. Componentes que se repiten

Están como funciones en `generadores/gen_ag.py`. Conviene que sean componentes Svelte.

### 4.1 Mapa del recorrido (`map_panel`)

- Base 398 x 300 en vertical, 462 x 348 en horizontal, 700 x 528 en tableta.
- Sin línea de sendero trazada: solo los puntos.
- Punto ya escuchado: círculo blanco de r=7 con borde navy.
- Punto actual: círculo blanco de r=9 con anillo verde de 3,5, más un halo verde al 30 %.
- Punto por venir: círculo blanco al 55 % de opacidad, r=6.
- Tu posición GPS: círculo azul `--ag-gps` de r=7,5 sobre disco blanco de r=11, con halo
  al 18 %. **El azul es deliberado**: sobre un bosque verde, un punto verde se leería como
  un punto más del recorrido.
- Los nombres de las paradas van como etiquetas al lado de cada punto.

**Límite conocido:** las 10 etiquetas de la Cascada entran justo. Arrayanes tiene 18 puntos
y Hasburgo 17, y ahí no entran. Para esos recorridos hay que resolver otra cosa, por
ejemplo mostrar solo el punto actual y sus vecinos inmediatos.

### 4.2 Avance del sendero (`trail_progress`)

Es la barra horizontal de progreso del recorrido completo, distinta del scrubber del audio.

- Inicio a la izquierda, fin a la derecha, con el nombre del destino.
- Una marca por punto: blanco lleno los escuchados, blanco al 38 % los que faltan.
- Cabezal arrastrable de 18 px, blanco con centro verde, que se mueve con la persona: si
  camina despacio se mueve despacio, si vuelve para atrás vuelve para atrás.
- Debajo, el resumen: distancia hecha, tiempo transcurrido y puntos escuchados.
- Es el mismo componente en las tres maquetas. Mantenelo como uno solo.

### 4.3 Tarjeta del punto actual (`current_point_card`)

Miniatura de 56 px, volanta verde de 10 px con "Punto N de M · a X m", título de 16 px,
y a la derecha un botón redondo. Es idéntica en las tres maquetas.

### 4.4 Botón de la foto (`foto_toggle`)

- **Siempre el ícono de foto, nunca una X.** Una X en la tarjeta se lee como cerrar el
  punto o el relato, no la foto.
- Con la foto cerrada: fondo blanco al 14 % sobre navy, ícono blanco.
- Con la foto abierta: invertido, círculo blanco lleno con el ícono en navy.
- Lleva `aria-pressed`, así el lector de pantalla lo anuncia como activado o desactivado.
- En tableta el botón no abre nada, porque la foto ya está a la vista: amplía a pantalla
  completa.
- **Mostralo solo mientras el punto está activo.** Cuando la persona ya se alejó, ocultalo:
  si no, queda un control que abre la foto de un punto que dejaron atrás.

---

## 5. La foto del punto

Una sola foto por punto.

### Cómo aparece

Al llegar al punto, la foto se muestra como una **postal sobre el mapa**: marco blanco de
9 px, sombra, y el mapa detrás bajo un velo `rgba(11,32,51,0.58)` para que se lea como un
popup y no como parte del mapa.

### Regla de tamaño, que vale para cualquier ratio

La foto crece hasta tocar el lado que la limita, y lo **pasa 4 px para cada lado**.

- Foto vertical: se pasa arriba y abajo.
- Foto apaisada: se pasa por los costados.
- Foto del mismo ratio que el hueco: lo tapa entero.

Ese excedente es lo que la hace leer como algo apoyado encima, y no como un recorte del
mapa. Medidas resultantes con la foto 3:4 de ejemplo:

| Pantalla | Hueco del mapa | Postal |
|---|---|---|
| Vertical | 398 x 300 | 236 x 308 |
| Horizontal | 462 x 348 | 272 x 356 |

Nota de contenido: cuanto más se aleja el ratio de la foto del ratio del hueco, más chica
queda. Conviene que las fotos nuevas sean apaisadas o cuadradas.

### Cómo se cierra

Tres caminos:

1. La X montada en la esquina superior derecha de la foto.
2. El botón de la tarjeta del punto, que está invertido.
3. **Sola**, cuando se cumplen las dos condiciones a la vez:
   - el relato del punto terminó, **y**
   - la persona se alejó más de **20 metros** del punto.

Sobre esos 20 metros: bajo el dosel del bosque el GPS del teléfono tiene entre 5 y 10 metros
de error. Con un umbral chico, de 5 metros, la foto se cierra y se vuelve a abrir sola
mientras la persona está parada mirando, y eso es peor que no tenerla. La condición del
relato terminado evita además que se cierre en medio de la explicación.

Si la cerraron a mano, no vuelve a aparecer sola para ese punto.

### Otros detalles

- Tocando la foto se amplía a pantalla completa. Un cartel se reconoce a 200 px, un nudo en
  un tronco no.
- Sin título ni epígrafe sobre la foto: el título del punto ya está abajo, con el relato.
- El `alt` tiene que describir lo que se ve, no repetir el nombre del punto.
- A evaluar: una vibración corta al abrirse, porque el acompañante puede estar mirando el
  sendero y no el teléfono.

---

## 6. Contraste y accesibilidad

Decisiones tomadas y por qué, para que no se deshagan sin querer:

- **`#348E4E` da 4,10:1 sobre blanco y no llega al mínimo AA.** Para texto chico sobre
  blanco usá `--ag-green-ink` (#2A7440), que da 5,72:1. El #348E4E queda para íconos,
  bordes y detalles grandes.
- El verde sobre navy de página daba 4,4:1, por eso la barra inferior de la pantalla oscura
  va sobre #0B2033, que lo lleva a 6,4:1.
- Todo control es un `<button>` o un `<a href>` real, nunca un `div` con `onClick`, para
  que el Tab los alcance.
- Los botones con solo ícono llevan `aria-label`.
- Las dos barras deslizables tienen `role="slider"` con `aria-valuemin`, `aria-valuemax`,
  `aria-valuenow` y `aria-valuetext`.
- Targets de 44 px. En horizontal bajan a 38, que es el mínimo aceptable ahí.

---

## 7. Qué falta del lado de los datos

Esto no se puede maquetar: hay que agregarlo al JSON del tour.

1. **Descripción del recorrido.** Hoy el JSON no la trae. En la pantalla de detalle quedó
   un placeholder. Hace falta un campo de texto por recorrido.
2. **Línea de "qué mirar" por punto.** La foto te dice cómo es la cosa, pero no dónde está.
   Una línea tipo "Buscá el cartel verde a la derecha de la senda, a la altura de tus ojos"
   es probablemente lo más útil de todo esto para el acompañante. Hoy no existe.
3. **Foto por punto.** Hay una sola foto cargada, la del punto 07 de la Cascada.
4. **Largo real del sendero.** Los kilómetros que muestran las maquetas salen de sumar las
   rectas entre puntos: Cascada 0,52 km, Arrayanes 1,45 km, Hasburgo 1,71 km. **No es el
   largo real.** Para eso hay que guardar el track completo, no solo los puntos.
5. **Textos de la tienda.** La sección de merchandising tiene copy de relleno marcado.

---

## 8. El mapa base: lo importante

`assets/mapa-base-PROVISORIO.jpg` es una captura de Google Maps usada solo para la maqueta.
**No se puede publicar.**

Google Maps no sirve para este producto, y no es una cuestión de precio. Los términos de la
Tile API prohíben expresamente almacenar o cachear el contenido, y listan el uso offline
entre los usos prohibidos. Una app de senderos que funciona sin señal es exactamente eso.

La alternativa viable es el **Instituto Geográfico Nacional de Argentina**: sus términos
permiten copiar, redistribuir y modificar, es gratuito, y pide la atribución
`FUENTE: Instituto Geográfico Nacional de la República Argentina`.

Propuesta concreta: **una imagen satelital estática por recorrido**, con licencia,
incluida en el paquete de descarga offline junto con los audios. No un mapa de tiles vivo.

Georreferenciación de la maqueta actual, por si sirve de referencia: está anclada en el pin
de la Cascada suponiendo zoom 17, o sea 0,899 metros por píxel, con el norte arriba. La
fórmula es `156543.03392 * cos(lat) / 2**zoom`; a latitud -41,18 y zoom 17 da 0,8989 m/px.
Las posiciones de los 10 puntos salen de las coordenadas reales del JSON, así que su
disposición relativa es correcta aunque cambiemos la base.

---

## 9. Orden sugerido para implementar

1. `tokens.css` y la barra de navegación de cuatro pestañas, en los tres breakpoints.
2. Inicio, Explorar, Offline y Sobre. Son las de menos estado y dejan el layout resuelto.
3. Detalle del recorrido.
4. Recorrido en curso sin la foto: mapa, avance del sendero, tarjeta del punto, scrubber
   y transporte.
5. La foto del punto, con su regla de tamaño y las dos condiciones de cierre automático.
6. Reemplazo del mapa base por la imagen del IGN.
7. Tableta en vertical.
8. Cuenta, login y editor, que todavía no están diseñados.
