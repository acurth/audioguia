#!/usr/bin/env python3
"""Redesigned audioguia.io screens, built on the Energy Briefs layout language."""
import math
import pathlib

OUT = pathlib.Path("/home/claude/agn/canvas/project")
OUT.mkdir(parents=True, exist_ok=True)

W, H = 430, 932

NAVY = "#102C44"
NAVY_PANEL = "#1A3E5A"
CYAN = "#4FB56C"          # brand green, for accents on navy
GPS = "#3B9DFF"           # GPS blue: the one colour outside the brand, so "you" never
                          # reads as one more point of the trail on a green forest
GREEN = "#348E4E"         # Natural Green: el color de los detalles
CYAN_INK = "#2A7440"      # el mismo verde, un punto más oscuro, para texto chico
                          # sobre blanco: #348E4E da 4,1:1 y no llega al mínimo
CYAN_SOFT = "#E9F4ED"
CYAN_LINE = "#A9D6B8"
PAGE = "#F5F8FA"
BORDER = "#DCE4EB"
FG1 = "#102C44"
FG2 = "#44586B"
FG3 = "#6B7C8C"
MUTED = "#9AA8B4"
ON_DARK_2 = "#A9C4D6"
ON_DARK_3 = "#7E9CB4"

# Escala de espaciado (base 4): lado 16 · entre secciones 24 · tarjeta 14/16 ·
# items 8 · arriba, en las pantallas que abren con el isologo grande: 72
S_SIDE, S_SECTION, S_TOP_LOGO = 16, 24, 55

LOGO_H = "/_blob/165a51e34b8b2cedddc782a207438c10"
LOGO_H_WHITE = "/_blob/37fe82f743b90eff6d15e5fdac43d9f8"
ICON = "/_blob/6343d66043a3d941f3d3f00c9b519853"
BG_CASCADA = "/_blob/79e2bda7bf7f973bf4b241defb027189"
BG_ARRAYANES = "/_blob/41d3c54e9369d35246850246e28db5bf"
BG_HASBURGO = "/_blob/e4e8c0466935e90ac16a98957d655c08"
PT007 = "/_blob/7d00855f9e878fbb56bbe5272d8f12e6"

# --- icons ------------------------------------------------------------------
STROKE = {
    "home": '<path d="m3 10 9-7 9 7v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><path d="M9 21v-7h6v7"></path>',
    "compass": '<circle cx="12" cy="12" r="9"></circle><path d="m15.5 8.5-2.2 5-5 2.2 2.2-5z"></path>',
    "download": '<path d="M12 3v12"></path><path d="m7 11 5 5 5-5"></path><path d="M5 21h14"></path>',
    "account": '<circle cx="12" cy="8" r="4"></circle><path d="M4 21v-1a7 7 0 0 1 14 0v1"></path>',
    "search": '<circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path>',
    "heart": '<path d="M19 14c1.5-1.5 3-3.3 3-5.5A4.5 4.5 0 0 0 12 5.5 4.5 4.5 0 0 0 2 8.5c0 2.2 1.5 4 3 5.5l7 7Z"></path>',
    "share": '<circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><path d="m8.6 13.5 6.8 4M15.4 6.5 8.6 10.5"></path>',
    "clock": '<circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3 2"></path>',
    "chevron-left": '<path d="m15 18-6-6 6-6"></path>',
    "chevron-right": '<path d="m9 18 6-6-6-6"></path>',
    "chevron-down": '<path d="m6 9 6 6 6-6"></path>',
    "x": '<path d="M18 6 6 18M6 6l12 12"></path>',
    "filter": '<path d="M4 6h16M7 12h10M10 18h4"></path>',
    "list": '<path d="M8 6h12M8 12h12M8 18h12M3.6 6h.01M3.6 12h.01M3.6 18h.01"></path>',
    "trash": '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"></path>',
    "lock": '<rect x="4" y="10" width="16" height="10" rx="2"></rect><path d="M8 10V7a4 4 0 0 1 8 0v3"></path>',
    "check": '<path d="m5 13 4 4 10-10"></path>',
    "map-pin": '<path d="M12 21s7-6.3 7-11a7 7 0 1 0-14 0c0 4.7 7 11 7 11z"></path><circle cx="12" cy="10" r="2.5"></circle>',
    "headphones": '<path d="M4 15v-3a8 8 0 0 1 16 0v3"></path><path d="M4 15a2 2 0 0 1 2-2h1v6H6a2 2 0 0 1-2-2z"></path><path d="M20 15a2 2 0 0 0-2-2h-1v6h1a2 2 0 0 0 2-2z"></path>',
    "ruler": '<path d="M4 12h16M7 9l-3 3 3 3M17 9l3 3-3 3"></path>',
    "accessibility": '<circle cx="12" cy="4.2" r="1.8"></circle><path d="M4.5 8.2h15M12 8.2v5.3m0 0-3.2 6.8M12 13.5l3.2 6.8"></path>',
    "crosshair": '<circle cx="12" cy="12" r="6.5"></circle><path d="M12 2v3M12 19v3M2 12h3M19 12h3"></path>',
    "mountain": '<path d="M3 19h18L14 6l-3.4 6-2-3z"></path>',
    "plus": '<path d="M12 5v14M5 12h14"></path>',
    "expand": '<path d="M9 3H3v6M15 3h6v6M9 21H3v-6M15 21h6v-6"></path>',
    "image": '<rect x="3" y="4" width="18" height="16" rx="2.5"></rect><circle cx="8.6" cy="9.6" r="1.6"></circle><path d="m4 17 4.6-4.6a1.6 1.6 0 0 1 2.3 0L15 16.5M14 15l1.7-1.7a1.6 1.6 0 0 1 2.3 0L20 15.5"></path>',
}
FILL = {
    "play": '<path d="M8 5v14l11-7z"></path>',
    "pause": '<rect x="6" y="5" width="4" height="14" rx="1"></rect><rect x="14" y="5" width="4" height="14" rx="1"></rect>',
    "stop": '<rect x="6" y="6" width="12" height="12" rx="2"></rect>',
    "skip-back": '<path d="M12.5 12 20 6.5v11zM3.5 12 11 6.5v11z"></path>',
    "more": '<circle cx="12" cy="5" r="1.6"></circle><circle cx="12" cy="12" r="1.6"></circle><circle cx="12" cy="19" r="1.6"></circle>',
}


def ic(name, size=24, stroke=2):
    if name in FILL:
        return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="currentColor" stroke="none" '
                f'aria-hidden="true" style="display:block;">{FILL[name]}</svg>')
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
            f'stroke-width="{stroke}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" '
            f'style="display:block;">{STROKE[name]}</svg>')


# --- shared chrome ----------------------------------------------------------
def header(search_href="AG-Explorar.dc.html"):
    return f'''  <header style="height:60px;flex:none;display:flex;align-items:center;justify-content:space-between;padding:0 16px;border-bottom:1px solid {BORDER};background:#fff;box-sizing:border-box;">
    <a href="AG-Inicio.dc.html" aria-label="Ir al inicio" style="display:flex;align-items:center;text-decoration:none;">
      <img src="{LOGO_H}" alt="audioguia.io" style="height:32px;width:128px;display:block;object-fit:contain;">
    </a>
    <a href="{search_href}" aria-label="Buscar recorridos" style="width:38px;height:38px;display:flex;align-items:center;justify-content:center;background:{PAGE};border:1px solid {BORDER};border-radius:999px;color:{FG1};flex:none;">{ic('search', 18)}</a>
  </header>'''


NAV = [("home", "Inicio", "AG-Inicio.dc.html"), ("compass", "Explorar", "AG-Explorar.dc.html"),
       ("download", "Offline", "AG-Offline.dc.html"), ("account", "Cuenta", "AG-Cuenta.dc.html")]


def nav(active):
    rows = []
    for name, label, href in NAV:
        on = name == active
        col = CYAN_INK if on else MUTED
        wt = 700 if on else 600
        cur = ' aria-current="page"' if on else ""
        rows.append(f'    <a href="{href}"{cur} style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;color:{col};text-decoration:none;padding:2px 0;">'
                    f'{ic(name, 22, 2.4 if on else 2)}<span style="font-size:10px;font-weight:{wt};">{label}</span></a>')
    return (f'  <nav style="flex:none;display:flex;background:#fff;border-top:1px solid {BORDER};padding:8px 0 18px;">\n'
            + "\n".join(rows) + "\n  </nav>")


NAV_DARK = "#0B2033"       # más oscuro que el fondo de la pantalla, así la barra se
                           # despega en vez de fundirse, y el verde llega a 6,4:1


def nav_inverted(active="compass"):
    rows = []
    for name, label, href in NAV:
        on = name == active
        col = CYAN if on else ON_DARK_3
        bg = "background:rgba(79,181,108,0.14);" if on else ""
        cur = ' aria-current="page"' if on else ""
        rows.append(f'    <a href="{href}"{cur} style="flex:1;display:flex;flex-direction:column;align-items:center;'
                    f'justify-content:center;gap:3px;color:{col};text-decoration:none;padding:4px 0;margin:0 6px;'
                    f'border-radius:10px;{bg}">{ic(name, 22, 2.4 if on else 2)}'
                    f'<span style="font-size:10px;font-weight:{700 if on else 600};">{label}</span></a>')
    return (f'  <nav aria-label="Navegación principal" style="flex:none;display:flex;background:{NAV_DARK};'
            f'border-top:1px solid rgba(255,255,255,0.10);padding:8px 0 18px;">\n'
            + "\n".join(rows) + "\n  </nav>")


def eyebrow(label, mb=0):
    m = f"margin-bottom:{mb}px;" if mb else ""
    return (f'<div style="display:flex;align-items:center;gap:8px;{m}">'
            f'<span style="width:24px;height:2px;background:{GREEN};display:block;flex:none;"></span>'
            f'<span style="font-size:11px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:{CYAN_INK};">{label}</span></div>')


def mark(label, icon="accessibility", on_dark=False):
    border = "none" if on_dark else f"1px solid {BORDER}"
    return (f'<span style="display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:4px 11px 4px 8px;'
            f'background:#fff;border:{border};white-space:nowrap;">'
            f'<span style="color:{GREEN};display:flex;">{ic(icon, 13, 2.2)}</span>'
            f'<span style="font-size:10.5px;font-weight:700;letter-spacing:0.02em;line-height:1;color:{CYAN_INK};">{label}</span></span>')


OFFLINE_CHIP = (f'<span style="display:inline-flex;align-items:center;gap:5px;border-radius:999px;padding:3px 9px;'
                f'background:{CYAN_SOFT};border:1px solid {CYAN_LINE};color:{CYAN_INK};font-size:10.5px;font-weight:700;white-space:nowrap;">'
                f'<span style="display:flex;">{ic("check", 12, 3)}</span>Offline listo</span>')

DOT = f'<span style="width:2.5px;height:2.5px;border-radius:50%;background:{MUTED};flex:none;"></span>'


def trail_row(img, title, meta, difficulty, offline=False, href="AG-Detalle.dc.html"):
    chip = f'<div style="margin-top:7px;">{OFFLINE_CHIP}</div>' if offline else ""
    dl_col = CYAN_INK if offline else FG2
    dl_bg = CYAN_SOFT if offline else PAGE
    dl_bd = CYAN_LINE if offline else BORDER
    return f'''      <div style="display:flex;gap:12px;align-items:flex-start;background:#fff;border:1px solid {BORDER};border-radius:8px;padding:10px;box-shadow:0 1px 2px rgba(16,44,68,0.06);box-sizing:border-box;">
        <a href="{href}" style="display:flex;gap:12px;align-items:flex-start;flex:1;min-width:0;text-decoration:none;color:inherit;">
          <img src="{img}" alt="" style="width:64px;height:64px;flex:none;border-radius:6px;object-fit:cover;">
          <div style="flex:1;min-width:0;">
            <div style="font-size:14px;font-weight:700;color:{FG1};line-height:1.25;margin-bottom:7px;">{title}</div>
            <div style="margin-bottom:6px;">{mark(difficulty)}</div>
            <div style="display:flex;align-items:center;gap:6px;font-size:11.5px;color:{FG3};flex-wrap:wrap;">{meta}</div>
            {chip}
          </div>
        </a>
        <div style="display:flex;flex-direction:column;gap:6px;flex:none;align-items:center;">
          <a href="AG-Recorrido.dc.html" aria-label="Iniciar recorrido" style="width:38px;height:38px;flex:none;display:flex;align-items:center;justify-content:center;background:{PAGE};border:1px solid {BORDER};border-radius:50%;color:{GREEN};">{ic('play', 15)}</a>
          <button type="button" aria-label="Descargar" style="width:38px;height:38px;flex:none;display:flex;align-items:center;justify-content:center;background:{dl_bg};border:1px solid {dl_bd};border-radius:50%;cursor:pointer;color:{dl_col};">{ic('download', 15)}</button>
        </div>
      </div>'''


ROW_CASCADA = trail_row(BG_CASCADA, "Cascada de los Duendes",
                        f'<span>0,52 km</span>{DOT}<span>10 puntos</span>{DOT}<span>11,59 MB</span>{DOT}<span>a ~740 m</span>',
                        "Sendero fácil", offline=True)
ROW_ARRAYANES = trail_row(BG_ARRAYANES, "Sendero de los Arrayanes",
                          f'<span>1,45 km</span>{DOT}<span>18 puntos</span>{DOT}<span>15,34 MB</span>{DOT}<span>a ~3,4 km</span>',
                          "Sendero fácil")
ROW_HASBURGO = trail_row(BG_HASBURGO, "Sendero a la Piedra de Hasburgo",
                         f'<span>1,71 km</span>{DOT}<span>17 puntos</span>{DOT}<span>22,74 MB</span>{DOT}<span>a ~8,1 km</span>',
                         "Sendero exigente")


def hero_card():
    return f'''      <div style="background:{NAVY};border-radius:12px;overflow:hidden;box-shadow:0 8px 24px rgba(16,44,68,0.18);">
        <a href="AG-Detalle.dc.html" aria-label="Cascada de los Duendes" style="position:relative;display:block;height:188px;background:#081c2e;">
          <img src="{BG_CASCADA}" alt="" style="width:100%;height:100%;object-fit:cover;display:block;">
          <span aria-hidden="true" style="position:absolute;inset:0;background:rgba(16,44,68,0.42);"></span>
          <span style="position:absolute;top:12px;right:12px;display:flex;align-items:center;gap:5px;background:rgba(16,44,68,0.66);border:1px solid rgba(255,255,255,0.18);border-radius:999px;padding:5px 10px;color:#fff;">{ic('map-pin', 12, 2.2)}<span style="font-size:11px;font-weight:700;">10 puntos</span></span>
        </a>
        <div style="padding:16px 18px 18px;">
          <div style="margin-bottom:11px;display:flex;align-items:center;gap:8px;">{mark('Sendero fácil', 'accessibility', True)}{OFFLINE_CHIP}</div>
          <a href="AG-Detalle.dc.html" style="display:block;margin:0 0 8px;font-size:21px;line-height:1.2;font-weight:700;color:#fff;letter-spacing:-0.01em;text-decoration:none;">Cascada de los Duendes</a>
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;font-size:13px;color:{ON_DARK_2};">
            <span>0,52 km</span><span style="width:3px;height:3px;border-radius:50%;background:#4E6E8A;"></span><span>10 puntos</span><span style="width:3px;height:3px;border-radius:50%;background:#4E6E8A;"></span><span>a ~740 m tuyo</span>
          </div>
          <div style="display:flex;align-items:center;gap:12px;">
            <a href="AG-Recorrido.dc.html" style="flex:1;display:flex;align-items:center;justify-content:center;gap:9px;background:#fff;color:{NAVY};border-radius:999px;padding:13px;font-size:15px;font-weight:700;text-decoration:none;">{ic('play', 17)}Iniciar recorrido</a>
            <button type="button" aria-label="Guardar en favoritos" style="width:46px;height:46px;flex:none;display:flex;align-items:center;justify-content:center;background:transparent;color:#A9C4D6;border:1px solid rgba(255,255,255,0.24);border-radius:50%;cursor:pointer;">{ic('heart', 19)}</button>
            <button type="button" aria-label="Descargar para usar sin conexión" style="width:46px;height:46px;flex:none;display:flex;align-items:center;justify-content:center;background:rgba(79,181,108,0.14);color:{CYAN};border:1px solid rgba(79,181,108,0.4);border-radius:50%;cursor:pointer;">{ic('download', 19)}</button>
          </div>
        </div>
      </div>'''


def page(title, body, bg="#fff"):
    return f'''<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;0,900;1,400&amp;display=swap">
<style>
body{{margin:0;font-family:'Lato','Helvetica Neue',Calibri,Arial,sans-serif;background:#e8edf1;color:{FG1};-webkit-font-smoothing:antialiased}}
a{{color:inherit}}
button{{font-family:'Lato','Helvetica Neue',Calibri,Arial,sans-serif}}
</style>
</helmet>
<div style="width:{W}px;height:{H}px;box-sizing:border-box;position:relative;display:flex;flex-direction:column;background:{bg};overflow:hidden;font-family:'Lato','Helvetica Neue',Calibri,Arial,sans-serif;color:{FG1};">
{body}
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{{"$preview":{{"width":{W},"height":{H}}}}}'>
class Component extends DCLogic {{
  renderVals() {{
    return {{}};
  }}
}}
</script>
</body>
</html>
'''


def scroll(inner, bg=PAGE):
    # The phone frame stays fixed and the body scrolls, same as .screen__scroll in the
    # real app. With overflow hidden the artboard could not be scrolled in Play.
    return f'''  <div style="flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;background:{bg};">
{inner}
  </div>'''


# --- 1. Inicio --------------------------------------------------------------
PHOTO = "/_blob/8b12b312d5ebbb7673837a72bda6ce21"
MERCH = "/_blob/be76f6f98987f725fb7c1624fa8940df"
GREEN_CTA = "#2A7440"     # el verde oscuro de la marca: sobre él el texto blanco
                          # llega a 5,7:1, cosa que el #348E4E no hace

inicio_scroll = f'''    <!-- aire superior: 55px, medido por Ax. Es la misma medida en todas las pantallas
         verticales que muestran el isologo grande. -->
    <section style="padding:55px 16px 0;background:#fff;">
      <div style="display:flex;justify-content:center;margin-bottom:14px;">
        <img src="{LOGO_H}" alt="audioguia.io" style="width:252px;height:63px;object-fit:contain;display:block;">
      </div>
      <h1 style="margin:0 0 8px;font-size:26px;line-height:1.15;font-weight:900;color:{FG1};letter-spacing:-0.015em;text-align:center;">Senderos para escuchar</h1>
      <p style="margin:0 0 14px;font-size:14.5px;line-height:1.55;color:{FG2};text-align:center;">Una audioguía accesible para recorrer senderos naturales a través del sonido. Los relatos se activan solos a medida que caminás.</p>
      <div style="border-radius:12px;overflow:hidden;margin-bottom:12px;">
        <img src="{PHOTO}" alt="Dos personas caminando por una pasarela de madera en el bosque, una de ellas con bastón blanco." style="width:100%;height:340px;object-fit:cover;object-position:50% 31%;display:block;">
      </div>
      <p style="margin:0 0 10px;font-size:14.5px;line-height:1.55;color:{FG2};text-align:center;">Los senderos se caminan acompañados: la app guía con imágenes a quien acompaña, y el relato y las señales sonoras acompañan a quienes escuchan.</p>
      <div style="text-align:center;">
        <a href="AG-Sobre.dc.html" style="display:inline-flex;align-items:center;gap:6px;font-size:14.5px;font-weight:700;color:{CYAN_INK};text-decoration:none;">Cómo funciona {ic('chevron-right', 16)}</a>
      </div>
    </section>

    <section style="padding:24px 16px 0;">
      <div style="background:{GREEN_CTA};border-radius:12px;padding:16px;box-sizing:border-box;">
        <label for="q" style="display:block;font-size:11px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:#CFE8D8;margin-bottom:10px;">Buscá un recorrido</label>
        <div style="display:flex;align-items:center;gap:10px;background:#fff;border-radius:8px;padding:13px 14px;box-sizing:border-box;margin-bottom:10px;">
          <span style="color:{GREEN};display:flex;flex:none;">{ic('search', 19)}</span>
          <input id="q" type="search" placeholder="Sendero, lugar o tema" style="flex:1;min-width:0;border:none;outline:none;background:transparent;font-family:inherit;font-size:14.5px;color:{FG1};">
        </div>
        <a href="AG-Explorar.dc.html" style="display:flex;align-items:center;justify-content:center;gap:8px;border:1.5px solid rgba(255,255,255,0.5);border-radius:999px;padding:12px;color:#fff;font-size:14.5px;font-weight:700;text-decoration:none;box-sizing:border-box;">Explorar todos los recorridos {ic('chevron-right', 16)}</a>
      </div>
    </section>

    <section style="padding:24px 16px 24px;">
      {eyebrow('Tienda', 12)}
      <div style="background:#fff;border:1px solid {BORDER};border-radius:12px;overflow:hidden;box-sizing:border-box;">
        <img src="{MERCH}" alt="Gorra, taza, remera y birome con el logo de audioguia.io." style="width:100%;height:172px;object-fit:cover;display:block;">
        <div style="padding:14px 16px 16px;">
          <div style="font-size:15px;font-weight:700;color:{FG1};margin-bottom:5px;">Gorras, remeras, tazas y biromes</div>
          <p style="margin:0 0 10px;font-size:12.5px;line-height:1.55;color:{FG2};">Con el logo de audioguia.io. [QUÉ CONTAMOS ACÁ SOBRE LA TIENDA: a dónde va lo recaudado, envíos, dónde se retira.]</p>
          <a href="AG-Inicio.dc.html" style="display:inline-flex;align-items:center;gap:6px;font-size:13.5px;font-weight:700;color:{CYAN_INK};text-decoration:none;">Ver la tienda {ic('chevron-right', 15)}</a>
        </div>
      </div>
    </section>'''

(OUT / "AG-Inicio.dc.html").write_text(page(
    "audioguia.io — Inicio", scroll(inicio_scroll, "#fff") + "\n" + nav("home")))


# --- 2. Inicio con mini player ---------------------------------------------
def mini_player():
    return f'''  <a href="AG-Recorrido.dc.html" aria-label="Volver al recorrido en curso" style="flex:none;background:{NAVY};position:relative;box-shadow:0 -8px 24px rgba(16,44,68,0.28);text-decoration:none;display:block;">
    <div style="display:flex;justify-content:center;padding-top:7px;"><span style="width:34px;height:4px;border-radius:999px;background:rgba(255,255,255,0.3);display:block;"></span></div>
    <div style="height:3px;background:rgba(255,255,255,0.18);margin-top:7px;"><div style="height:100%;width:62%;background:{GREEN};"></div></div>
    <div style="display:flex;align-items:center;gap:11px;padding:9px 14px;">
      <img src="{PT007}" alt="" style="width:40px;height:40px;border-radius:5px;object-fit:cover;flex:none;">
      <div style="flex:1;min-width:0;">
        <div style="font-size:12.5px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">07 · El Carpintero Gigante</div>
        <div style="display:flex;align-items:center;gap:8px;margin-top:3px;">
          <span style="display:inline-flex;align-items:center;gap:4px;font-size:10.5px;font-weight:700;color:{CYAN};"><span style="width:6px;height:6px;border-radius:999px;background:{CYAN};display:block;"></span>En recorrido</span>
          <span style="font-size:10.5px;color:{ON_DARK_3};">Cascada de los Duendes · 6 de 10</span>
        </div>
      </div>
      <button type="button" aria-label="Pausar" style="width:40px;height:40px;flex:none;display:flex;align-items:center;justify-content:center;background:#fff;border:none;border-radius:50%;cursor:pointer;color:{NAVY};">{ic('pause', 16)}</button>
    </div>
  </a>'''


(OUT / "AG-Inicio-Mini.dc.html").write_text(page(
    "audioguia.io — Inicio con recorrido en curso",
    scroll(inicio_scroll, "#fff") + "\n" + mini_player() + "\n" + nav("home")))

# --- 3. Explorar ------------------------------------------------------------
sort_bar = f'''  <div style="flex:none;background:#fff;border-bottom:1px solid {BORDER};padding:12px 16px;box-sizing:border-box;">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
      <h2 style="margin:0;font-size:22px;font-weight:900;color:{FG1};letter-spacing:-0.01em;">Explorar</h2>
      <button type="button" style="display:flex;align-items:center;gap:5px;background:transparent;border:none;cursor:pointer;color:{FG2};font-size:12px;font-weight:700;">{ic('filter', 15)}Filtros</button>
    </div>
    <div style="display:flex;gap:7px;overflow:hidden;">
      <button type="button" aria-pressed="true" style="flex:none;display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:700;color:{CYAN_INK};background:{CYAN_SOFT};border:1px solid {CYAN_LINE};border-radius:999px;padding:6px 12px;cursor:pointer;">{ic('map-pin', 13, 2.2)}Cerca mío</button>
      <button type="button" style="flex:none;font-size:12px;font-weight:700;color:{FG1};background:#fff;border:1px solid {BORDER};border-radius:999px;padding:6px 12px;cursor:pointer;">Más cortos</button>
      <button type="button" style="flex:none;font-size:12px;font-weight:700;color:{FG1};background:#fff;border:1px solid {BORDER};border-radius:999px;padding:6px 12px;cursor:pointer;">Accesibles</button>
      <button type="button" style="flex:none;font-size:12px;font-weight:700;color:{FG1};background:#fff;border:1px solid {BORDER};border-radius:999px;padding:6px 12px;cursor:pointer;">Descargados</button>
    </div>
  </div>'''

explorar_scroll = f'''    <div style="padding:16px 16px 8px;font-size:12px;color:{FG3};font-weight:600;">3 recorridos · ordenados por distancia</div>
    <section style="padding:0 16px 16px;display:flex;flex-direction:column;gap:8px;">
{ROW_CASCADA}
{ROW_ARRAYANES}
{ROW_HASBURGO}
    </section>
    <div style="padding:8px 16px 24px;">
      <p style="margin:0;font-size:12.5px;line-height:1.5;color:{FG3};">Recomendación: descargá el recorrido antes de salir del Wi-Fi o de una buena conexión de datos.</p>
    </div>'''

(OUT / "AG-Explorar.dc.html").write_text(page(
    "audioguia.io — Explorar", header() + "\n" + sort_bar + "\n" + scroll(explorar_scroll) + "\n" + nav("compass")))

# --- 4. Offline -------------------------------------------------------------
offline_head = f'''  <div style="flex:none;background:#fff;border-bottom:1px solid {BORDER};padding:16px;box-sizing:border-box;">
    <h2 style="margin:0 0 10px;font-size:22px;font-weight:900;color:{FG1};letter-spacing:-0.01em;">Offline</h2>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;background:{CYAN_SOFT};border:1px solid {CYAN_LINE};border-radius:8px;padding:10px 12px;box-sizing:border-box;">
      <div style="display:flex;align-items:center;gap:9px;color:{CYAN_INK};min-width:0;">
        {ic('download', 17, 2.2)}
        <span style="font-size:12.5px;font-weight:700;">1 recorrido descargado · 11,59 MB</span>
      </div>
      <button type="button" style="flex:none;background:none;border:none;cursor:pointer;color:{CYAN_INK};font-size:12px;font-weight:700;text-decoration:underline;">Liberar</button>
    </div>
  </div>'''

offline_scroll = f'''    <section style="padding:16px;display:flex;flex-direction:column;gap:8px;">
{ROW_CASCADA}
    </section>
    <div style="padding:8px 16px 24px;">
      <div style="background:#fff;border:1px solid {BORDER};border-radius:10px;padding:14px 15px;box-sizing:border-box;">
        <div style="font-size:13px;font-weight:700;color:{FG1};margin-bottom:5px;">Los descargados funcionan sin señal</div>
        <p style="margin:0 0 10px;font-size:12.5px;line-height:1.55;color:{FG2};">Quedan guardados los audios, las fotos y el mapa del recorrido. El GPS del teléfono sigue funcionando sin datos.</p>
        <a href="AG-Explorar.dc.html" style="display:inline-flex;align-items:center;gap:6px;font-size:13px;font-weight:700;color:{CYAN_INK};text-decoration:none;">Descargar otro recorrido {ic('chevron-right', 15)}</a>
      </div>
    </div>'''

(OUT / "AG-Offline.dc.html").write_text(page(
    "audioguia.io — Offline", header() + "\n" + offline_head + "\n" + scroll(offline_scroll) + "\n" + nav("download")))

# --- 5. Detalle del recorrido ----------------------------------------------
POINTS = [
    ("01", "Inicio Sendero Cascada de los Duendes", -41.179408, -71.414213),
    ("02", "Arroyo Pescadero", -41.179691, -71.415017),
    ("03", "El Rayadito", -41.180110, -71.415390),
    ("04", "Sentir el Arroyo", -41.180660, -71.415670),
    ("05", "Escalera de Piedras", -41.181439, -71.416328),
    ("06", "Seguimos la senda principal", -41.181800, -71.416600),
    ("07", "El Carpintero Gigante", -41.181870, -71.416979),
    ("08", "Bifurcación del Fío Fío", -41.182172, -71.417297),
    ("09", "El puente", -41.182100, -71.418000),
    ("10", "La Cascada de Los Duendes ♫︎", -41.182097, -71.418481),
]


def meters(a, b):
    (_, _, la1, lo1), (_, _, la2, lo2) = a, b
    dy = (la2 - la1) * 110574
    dx = (lo2 - lo1) * 111320 * math.cos(math.radians(la1))
    return math.hypot(dx, dy)


CUM = [0.0]
for i in range(1, len(POINTS)):
    CUM.append(CUM[-1] + meters(POINTS[i - 1], POINTS[i]))
TOTAL_M = CUM[-1]


def fmt_km(m):
    return f"{m/1000:.2f}".replace(".", ",") + " km"


detail_bar = f'''  <header style="height:52px;flex:none;display:flex;align-items:center;justify-content:space-between;padding:0 14px;background:#fff;box-sizing:border-box;">
    <a href="AG-Explorar.dc.html" aria-label="Volver" style="width:38px;height:38px;display:flex;align-items:center;justify-content:center;background:{PAGE};border:1px solid {BORDER};border-radius:999px;color:{FG1};">{ic('chevron-left', 19)}</a>
    <span style="font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:{FG3};">Detalle del recorrido</span>
    <button type="button" aria-label="Más opciones" style="width:38px;height:38px;display:flex;align-items:center;justify-content:center;background:{PAGE};border:1px solid {BORDER};border-radius:999px;cursor:pointer;color:{FG1};">{ic('more', 19)}</button>
  </header>'''

detail_scroll = f'''    <div style="position:relative;height:206px;background:#081c2e;flex:none;">
      <img src="{BG_CASCADA}" alt="" style="width:100%;height:100%;object-fit:cover;display:block;">
    </div>
    <div style="padding:16px 16px 24px;">
      <div style="display:flex;align-items:center;gap:9px;margin-bottom:12px;flex-wrap:wrap;">{mark('Sendero fácil')}{OFFLINE_CHIP}</div>
      <h1 style="margin:0 0 12px;font-size:25px;line-height:1.18;font-weight:900;color:{FG1};letter-spacing:-0.015em;">Cascada de los Duendes</h1>
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;font-size:12.5px;color:{FG3};flex-wrap:wrap;">
        <span>Bariloche</span><span style="width:3px;height:3px;border-radius:50%;background:{MUTED};"></span><span>{fmt_km(TOTAL_M)}</span><span style="width:3px;height:3px;border-radius:50%;background:{MUTED};"></span><span>10 puntos</span><span style="width:3px;height:3px;border-radius:50%;background:{MUTED};"></span><span>11,59 MB</span>
      </div>
      <div style="display:flex;align-items:center;gap:11px;margin-bottom:18px;">
        <img src="{ICON}" alt="" style="width:42px;height:42px;border-radius:10px;object-fit:cover;flex:none;">
        <div>
          <div style="font-size:14px;font-weight:700;color:{FG1};">Audioguía Natural</div>
          <div style="font-size:12px;color:{FG3};">Relato y grabación</div>
        </div>
      </div>
      <a href="AG-Recorrido.dc.html" style="width:100%;display:flex;align-items:center;justify-content:center;gap:12px;background:{NAVY};border-radius:10px;padding:18px;color:#fff;box-shadow:0 10px 24px rgba(16,44,68,0.26);box-sizing:border-box;text-decoration:none;">
        <span style="width:36px;height:36px;flex:none;display:flex;align-items:center;justify-content:center;background:rgba(79,181,108,0.22);border-radius:50%;color:{CYAN};">{ic('play', 16)}</span>
        <span style="font-size:16px;font-weight:800;letter-spacing:0.01em;">Iniciar recorrido</span>
        <span style="font-size:13px;font-weight:600;color:{ON_DARK_2};">10 puntos</span>
      </a>
      <div style="display:flex;gap:8px;margin-top:14px;">
        <button type="button" style="flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;background:#fff;border:1px solid {BORDER};border-radius:8px;padding:11px;cursor:pointer;color:{FG2};">{ic('heart', 20)}<span style="font-size:11px;font-weight:700;">Favorito</span></button>
        <button type="button" style="flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;background:{CYAN_SOFT};border:1px solid {CYAN_LINE};border-radius:8px;padding:11px;cursor:pointer;color:{CYAN_INK};">{ic('check', 20)}<span style="font-size:11px;font-weight:700;">Descargado</span></button>
        <button type="button" style="flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;background:#fff;border:1px solid {BORDER};border-radius:8px;padding:11px;cursor:pointer;color:{FG2};">{ic('share', 20)}<span style="font-size:11px;font-weight:700;">Compartir</span></button>
      </div>
      <section style="margin-top:24px;">
        {eyebrow('Sobre este recorrido', 12)}
        <p style="margin:0;font-size:14px;line-height:1.6;color:{FG1};">[DESCRIPCIÓN DEL RECORRIDO. Hoy el JSON del tour no la trae: hay que agregar un campo de texto por recorrido, o tomarlo del guion del audio del punto 01.]</p>
      </section>
      <section style="margin-top:24px;">
        {eyebrow('Antes de salir', 12)}
        <div style="display:flex;gap:10px;background:#fff;border:1px solid {BORDER};border-radius:8px;padding:13px 14px;box-sizing:border-box;">
          <span style="color:{GREEN};flex:none;display:flex;">{ic('headphones', 18, 2.1)}</span>
          <p style="margin:0;font-size:12.5px;line-height:1.55;color:{FG2};">Mantené la app abierta mientras caminás para que el GPS dispare los audios. Si el teléfono bloquea la pantalla, se pausa el seguimiento.</p>
        </div>
      </section>
    </div>'''

(OUT / "AG-Detalle.dc.html").write_text(page(
    "audioguia.io — Detalle del recorrido",
    detail_bar + "\n" + scroll(detail_scroll, "#fff") + "\n" + nav("compass")))

# --- mini map ---------------------------------------------------------------
# Base: provisional capture of the sector, georeferenced from the "Cascada de los
# Duendes" pin assuming zoom 17 (0.899 m/px), north up. Mockup only: it has to be
# replaced by a licensed image. Point positions come from the real lat/lng in the
# tour JSON, so their layout is accurate even if the base is not final.
MAP_W, MAP_H = 398, 300
MAP_IMG = "/_blob/39bb24d8f28e0507957e951aee461346"

PXY = [(320.8, 45.9), (274.9, 67.2), (253.6, 98.8), (237.6, 140.2), (200.1, 198.9),
       (184.6, 226.1), (162.9, 231.3), (144.8, 254.1), (104.7, 248.7), (77.2, 248.4)]
ACTIVE = 6
gx = PXY[5][0] + (PXY[6][0] - PXY[5][0]) * 0.8
gy = PXY[5][1] + (PXY[6][1] - PXY[5][1]) * 0.8
DONE_M = CUM[5] + (CUM[6] - CUM[5]) * 0.8

# Label placement tuned by hand so the ten names fit without colliding.
# ("right", x) pins the label's right edge at x; ("left", x) pins its left edge.
MAP_LABELS = [("right", 309, 38), ("right", 263, 59), ("right", 242, 91),
              ("right", 226, 132), ("right", 188, 185), ("left", 197, 207),
              ("left", 175, 240), ("left", 157, 272), ("right", 95, 227),
              ("left", 20, 272)]
MAP_NAMES = ["Inicio del sendero", "Arroyo Pescadero", "El Rayadito", "Sentir el Arroyo",
             "Escalera de Piedras", "Seguimos la senda principal", "El Carpintero Gigante",
             "Bifurcación del Fío Fío", "El puente", "La Cascada de Los Duendes"]


def map_points():
    out = []
    for i, (x, y) in enumerate(PXY):
        if i < ACTIVE:
            out.append(f'      <circle cx="{x}" cy="{y}" r="7" fill="#FFFFFF" stroke="{NAVY}" stroke-width="2"></circle>')
        elif i == ACTIVE:
            out.append(f'      <circle cx="{x}" cy="{y}" r="16" fill="{CYAN}" opacity="0.3"></circle>')
            out.append(f'      <circle cx="{x}" cy="{y}" r="9" fill="#FFFFFF" stroke="{GREEN}" stroke-width="3.5"></circle>')
        else:
            out.append(f'      <circle cx="{x}" cy="{y}" r="6" fill="#FFFFFF" opacity="0.55" stroke="{NAVY}" stroke-width="1.5"></circle>')
    return "\n".join(out)


def map_labels(sc=1.0):
    out = []
    for i, (side, edge, top) in enumerate(MAP_LABELS):
        pos = f"left:{edge * sc:.0f}px;" if side == "left" else f"right:{(MAP_W - edge) * sc:.0f}px;"
        if i == ACTIVE:
            skin, num = f"background:{CYAN_INK};color:#fff;", f'<b>{POINTS[i][0]}</b>'
        elif i < ACTIVE:
            skin, num = "background:rgba(16,44,68,0.84);color:#fff;", f'<b style="color:{CYAN};">{POINTS[i][0]}</b>'
        else:
            skin, num = "background:rgba(16,44,68,0.72);color:rgba(255,255,255,0.88);", f'<b style="color:rgba(255,255,255,0.72);">{POINTS[i][0]}</b>'
        out.append(f'    <span style="position:absolute;{pos}top:{top * sc:.0f}px;max-width:{116 * sc:.0f}px;{skin}'
                   f'font-size:{9 * sc:.1f}px;font-weight:700;line-height:1.25;padding:{2 * sc:.0f}px {5 * sc:.0f}px;border-radius:4px;'
                   f'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{num} {MAP_NAMES[i]}</span>')
    return "\n".join(out)


CROSSHAIR_BTN = (
    '\n    <button type="button" aria-label="Centrar el mapa en tu posición" '
    'style="position:absolute;top:10px;right:10px;width:36px;height:36px;display:flex;align-items:center;'
    'justify-content:center;background:rgba(16,44,68,0.82);border:1px solid rgba(255,255,255,0.14);'
    'border-radius:999px;cursor:pointer;color:#fff;">' + ic('crosshair', 17, 2) + '</button>')


def map_panel(height=MAP_H, labels=True, width=None, crosshair=True, over=""):
    """width set = the panel keeps the 398x300 ratio, so the labels scale with it
    and stay glued to their points. Without it the panel is cropped and labels go off."""
    sc = (width / MAP_W) if width else 1.0
    labs = ("\n" + map_labels(sc)) if labels else ""
    wcss = f"width:{width}px;" if width else ""
    cross = CROSSHAIR_BTN if crosshair else ""
    return f'''  <div style="position:relative;{wcss}height:{height}px;border-radius:14px;overflow:hidden;flex:none;background:#1B3A2C;">
    <svg viewBox="0 0 {MAP_W} {MAP_H}" preserveAspectRatio="xMidYMid slice" aria-label="Mapa del recorrido con los diez puntos y tu posición" style="display:block;width:100%;height:100%;">
      <image href="{MAP_IMG}" x="0" y="0" width="{MAP_W}" height="{MAP_H}" preserveAspectRatio="xMidYMid slice"></image>
{map_points()}
      <circle cx="{round(gx,1)}" cy="{round(gy,1)}" r="26" fill="{GPS}" opacity="0.18"></circle>
      <circle cx="{round(gx,1)}" cy="{round(gy,1)}" r="11" fill="#FFFFFF"></circle>
      <circle cx="{round(gx,1)}" cy="{round(gy,1)}" r="7.5" fill="{GPS}"></circle>
    </svg>{labs}{cross}
    <span style="position:absolute;left:10px;top:10px;font-size:9px;color:rgba(255,255,255,0.78);background:rgba(16,44,68,0.66);padding:2px 6px;border-radius:4px;">Base provisoria, solo para el mockup</span>{over}
  </div>'''


# --- 6. Recorrido en curso --------------------------------------------------
run_bar = f'''  <div style="flex:none;display:flex;align-items:center;justify-content:space-between;padding:12px 16px 8px;">
    <a href="AG-Detalle.dc.html" aria-label="Volver al detalle" style="width:38px;height:38px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.1);border-radius:999px;color:#fff;text-decoration:none;">{ic('chevron-down', 20, 2.2)}</a>
    <span style="display:inline-flex;align-items:center;gap:7px;font-size:11px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:{CYAN};"><span style="width:7px;height:7px;border-radius:999px;background:{CYAN};display:block;"></span>En recorrido</span>
    <button type="button" aria-label="Más opciones" style="width:38px;height:38px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.1);border:none;border-radius:999px;cursor:pointer;color:#fff;">{ic('more', 19)}</button>
  </div>
  <h1 style="flex:none;margin:2px 16px 12px;font-size:20px;font-weight:800;color:#fff;letter-spacing:-0.01em;text-align:center;line-height:1.2;">Cascada de los Duendes</h1>'''

transport = f'''    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;">
      <button type="button" aria-label="Velocidad de reproducción" style="display:flex;align-items:center;justify-content:center;min-width:42px;height:30px;padding:0 10px;background:rgba(255,255,255,0.12);border:none;border-radius:999px;color:#fff;font-size:12px;font-weight:700;cursor:pointer;">1×</button>
      <button type="button" aria-label="Retroceder 15 segundos" style="position:relative;width:44px;height:44px;display:flex;align-items:center;justify-content:center;background:none;border:none;cursor:pointer;color:#fff;">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"></path><path d="M3 4v4h4"></path></svg>
        <span style="position:absolute;font-size:8.5px;font-weight:800;">15</span>
      </button>
      <button type="button" aria-label="Pausar el relato" style="width:66px;height:66px;display:flex;align-items:center;justify-content:center;background:#fff;border:none;border-radius:50%;cursor:pointer;color:{NAVY};">{ic('pause', 26)}</button>
      <button type="button" aria-label="Adelantar 30 segundos" style="position:relative;width:44px;height:44px;display:flex;align-items:center;justify-content:center;background:none;border:none;cursor:pointer;color:#fff;">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 1 1-3-6.7L21 8"></path><path d="M21 4v4h-4"></path></svg>
        <span style="position:absolute;font-size:8.5px;font-weight:800;">30</span>
      </button>
      <span aria-hidden="true" style="width:42px;flex:none;"></span>
    </div>'''


def foto_toggle(open_=False, size=44, icon=20):
    """Botón de la foto del punto, a la derecha de la tarjeta. Mientras el punto
    está activo se puede abrir y cerrar la foto cuantas veces haga falta."""
    # Siempre el ícono de foto, nunca una X: una X acá se leería como cerrar el punto
    # o el relato. Cuando la foto está abierta el botón va invertido, blanco con el
    # ícono en navy, que es la forma de mostrar que está activado.
    lab = "Cerrar la foto del punto" if open_ else "Ver la foto del punto"
    skin = f"background:#fff;color:{NAVY};" if open_ else "background:rgba(255,255,255,0.14);color:#fff;"
    glyph = ic('image', icon, 2 if not open_ else 2.2)
    press = "true" if open_ else "false"
    return (f'<button type="button" aria-label="{lab}" aria-pressed="{press}" style="width:{size}px;height:{size}px;'
            f'flex:none;display:flex;align-items:center;justify-content:center;{skin}border:none;border-radius:50%;'
            f'cursor:pointer;">{glyph}</button>')


def ampliar_btn(size=44, icon=20):
    """En tableta la foto del punto ya está a la vista, así que el botón no abre
    nada: amplía la foto a pantalla completa."""
    return (f'<button type="button" aria-label="Ampliar la foto del punto" style="width:{size}px;height:{size}px;'
            f'flex:none;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.14);'
            f'color:#fff;border:none;border-radius:50%;cursor:pointer;">' + ic('expand', icon, 2) + '</button>')


def current_point_card(margin_bottom=16, foto_open=False, btn=None):
    return f'''    <div style="display:flex;align-items:center;gap:12px;background:{NAVY_PANEL};border-radius:12px;padding:12px;margin-bottom:{margin_bottom}px;box-sizing:border-box;">
      <img src="{PT007}" alt="" style="width:56px;height:56px;border-radius:8px;object-fit:cover;flex:none;">
      <div style="flex:1;min-width:0;">
        <div style="font-size:10px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:{CYAN};margin-bottom:3px;">Punto 7 de 10 · a 6 m</div>
        <div style="font-size:16px;font-weight:700;color:#fff;line-height:1.2;">El Carpintero Gigante</div>
      </div>
      {btn if btn is not None else foto_toggle(foto_open)}
    </div>'''


def trail_progress(compact=False):
    """Horizontal progress of the WHOLE trail: start at the left, end at the right,
    a draggable head that moves with the walker, and one tick per point."""
    frac = DONE_M / TOTAL_M
    ticks = []
    for i in range(len(POINTS)):
        pct = CUM[i] / TOTAL_M * 100
        if i < 6:
            fill, op, r = "#FFFFFF", "1", 4
        elif i == 6:
            fill, op, r = CYAN, "1", 0
        else:
            fill, op, r = "#FFFFFF", "0.38", 3.5
        if i == 6:
            continue
        ticks.append(f'      <span aria-hidden="true" style="position:absolute;left:{pct:.1f}%;top:50%;transform:translate(-50%,-50%);width:{r*2}px;height:{r*2}px;border-radius:999px;background:{fill};opacity:{op};display:block;"></span>')
    head_pct = frac * 100
    label = "" if compact else f'''    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:9px;">
      <span style="font-size:11px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:{ON_DARK_2};">Avance del sendero</span>
      <span style="display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:700;color:#fff;font-variant-numeric:tabular-nums;">{ic('clock', 13, 2.2)}24:10</span>
    </div>
'''
    return f'''    <div style="flex:none;">
{label}    <div role="slider" tabindex="0" aria-label="Avance del sendero" aria-valuemin="0" aria-valuemax="{round(TOTAL_M)}" aria-valuenow="{round(DONE_M)}" aria-valuetext="{fmt_km(DONE_M)} de {fmt_km(TOTAL_M)}, punto 7 de 10" style="position:relative;height:6px;border-radius:999px;background:rgba(255,255,255,0.18);">
      <span aria-hidden="true" style="position:absolute;left:0;top:0;bottom:0;width:{head_pct:.1f}%;border-radius:999px;background:{GREEN};display:block;"></span>
{chr(10).join(ticks)}
      <span aria-hidden="true" style="position:absolute;left:{head_pct:.1f}%;top:50%;transform:translate(-50%,-50%);width:18px;height:18px;border-radius:999px;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,0.45);display:flex;align-items:center;justify-content:center;">
        <span style="width:8px;height:8px;border-radius:999px;background:{CYAN};display:block;"></span>
      </span>
    </div>
    <div style="display:flex;align-items:center;gap:10px;margin-top:7px;font-size:10.5px;color:{ON_DARK_3};">
      <span style="flex:none;">Inicio</span>
      <span style="flex:1;text-align:center;color:#fff;font-weight:700;font-variant-numeric:tabular-nums;">{fmt_km(DONE_M)} de {fmt_km(TOTAL_M)} · 24:10 · 6 de 10 puntos</span>
      <span style="flex:none;">Cascada</span>
    </div>
    </div>'''


scrubber = f'''    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
      <span style="font-size:11px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:{ON_DARK_2};">Relato del punto 07</span>
      <span style="display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:700;color:{CYAN};"><span style="width:6px;height:6px;border-radius:999px;background:{CYAN};display:block;"></span>Reproduciendo</span>
    </div>
    <div role="slider" aria-label="Avance del relato" aria-valuemin="0" aria-valuemax="100" aria-valuenow="62" tabindex="0" style="position:relative;height:5px;border-radius:999px;background:rgba(255,255,255,0.18);margin-bottom:9px;flex:none;">
      <div style="position:absolute;left:0;top:0;bottom:0;width:62%;border-radius:999px;background:{GREEN};"></div>
      <div style="position:absolute;top:50%;left:62%;transform:translate(-50%,-50%);width:14px;height:14px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,0.4);"></div>
    </div>
    <div style="display:flex;justify-content:space-between;margin-bottom:18px;font-size:11.5px;font-weight:600;">
      <span style="color:#fff;">1:12</span><span style="color:{ON_DARK_3};">-0:44</span>
    </div>'''

stop_btn = f'''    <a href="AG-Detalle.dc.html" style="display:flex;align-items:center;justify-content:center;gap:9px;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:999px;padding:13px;color:#fff;font-size:14px;font-weight:700;text-decoration:none;box-sizing:border-box;">{ic('stop', 16)}Detener recorrido</a>'''

run_body = f'''  <div style="flex:1;min-height:0;display:flex;flex-direction:column;padding:8px 16px 14px;box-sizing:border-box;">
{map_panel(300)}
    <div style="height:18px;flex:none;"></div>
{trail_progress()}
    <div style="height:18px;flex:none;"></div>
{current_point_card(16)}
{scrubber}
{transport}
{stop_btn}
  </div>'''

(OUT / "AG-Recorrido.dc.html").write_text(page(
    "audioguia.io — Recorrido en curso",
    run_bar + "\n" + run_body + "\n" + nav_inverted(), NAVY))

# --- 8. Sobre ---------------------------------------------------------------
sobre_scroll = f'''    <section style="padding:55px 16px 0;">
      <div style="display:flex;justify-content:center;margin-bottom:18px;">
        <img src="{LOGO_H}" alt="audioguia.io" style="width:224px;height:56px;object-fit:contain;display:block;">
      </div>
      <h1 style="margin:0 0 6px;font-size:25px;font-weight:900;color:{FG1};letter-spacing:-0.015em;text-align:center;">Senderos para escuchar</h1>
      <p style="margin:0 0 20px;font-size:14px;line-height:1.6;color:{FG2};text-align:center;">Una audioguía accesible para recorrer senderos naturales a través del sonido.</p>
      <div style="display:flex;flex-direction:column;gap:10px;">
        <div style="display:flex;gap:12px;background:#fff;border:1px solid {BORDER};border-radius:10px;padding:14px 15px;box-sizing:border-box;">
          <span style="color:{GREEN};flex:none;display:flex;">{ic('accessibility', 20, 2.1)}</span>
          <div>
            <div style="font-size:13.5px;font-weight:700;color:{FG1};margin-bottom:4px;">Pensada para escuchar</div>
            <p style="margin:0;font-size:12.5px;line-height:1.55;color:{FG2};">Está hecha para personas con discapacidad visual, y también para quienes quieran recorrer el entorno de otra manera.</p>
          </div>
        </div>
        <div style="display:flex;gap:12px;background:#fff;border:1px solid {BORDER};border-radius:10px;padding:14px 15px;box-sizing:border-box;">
          <span style="color:{GREEN};flex:none;display:flex;">{ic('map-pin', 20, 2.1)}</span>
          <div>
            <div style="font-size:13.5px;font-weight:700;color:{FG1};margin-bottom:4px;">Los audios se disparan solos</div>
            <p style="margin:0;font-size:12.5px;line-height:1.55;color:{FG2};">Cuando te acercás a un punto de interés se reproduce el relato. También podés reproducirlos a mano si lo necesitás.</p>
          </div>
        </div>
        <div style="display:flex;gap:12px;background:#fff;border:1px solid {BORDER};border-radius:10px;padding:14px 15px;box-sizing:border-box;">
          <span style="color:{GREEN};flex:none;display:flex;">{ic('download', 20, 2.1)}</span>
          <div>
            <div style="font-size:13.5px;font-weight:700;color:{FG1};margin-bottom:4px;">Funciona sin conexión</div>
            <p style="margin:0;font-size:12.5px;line-height:1.55;color:{FG2};">Descargá el recorrido antes de salir y los audios quedan disponibles aunque no haya señal ni datos.</p>
          </div>
        </div>
      </div>
    </section>
    <section style="padding:24px 16px 0;">
      {eyebrow('Agradecimientos', 12)}
      <p style="margin:0;font-size:13.5px;line-height:1.6;color:{FG2};">Pablo, Yamila, Lucas, Karin, Andre, Guille, Lorenzo, Juan y Axel.</p>
    </section>
    <section style="padding:24px 16px 24px;">
      <div style="border-top:1px solid {BORDER};padding-top:14px;font-size:12.5px;color:{FG3};line-height:1.7;">
        <div><strong style="color:{FG2};">Proyecto:</strong> audioguia.io</div>
        <div><strong style="color:{FG2};">Última actualización:</strong> 2026-02-21</div>
        <div><strong style="color:{FG2};">Versión app:</strong> 1.2.2 · <strong style="color:{FG2};">contenidos:</strong> 2026.02.21</div>
      </div>
      <p style="margin:14px 0 0;text-align:start;font-size:11px;color:{MUTED};">© 2026 audioguia.io. Todos los derechos reservados.</p>
    </section>'''

sobre_back = f'''  <a href="AG-Inicio.dc.html" aria-label="Volver" style="position:absolute;top:16px;left:16px;z-index:2;width:38px;height:38px;display:flex;align-items:center;justify-content:center;background:{PAGE};border:1px solid {BORDER};border-radius:999px;color:{FG1};text-decoration:none;">{ic('chevron-left', 19)}</a>'''

(OUT / "AG-Sobre.dc.html").write_text(page(
    "audioguia.io — Sobre", sobre_back + "\n" + scroll(sobre_scroll, "#fff") + "\n" + nav("home")))

# --- 9. Cuenta --------------------------------------------------------------
menu = [("download", "Descargas y espacio", "11,59 MB"), ("accessibility", "Accesibilidad y voz", None),
        ("share", "Compartir la app", None), ("map-pin", "Sobre la audioguía", None)]
menu_html = ""
for i, (icn, label, val) in enumerate(menu):
    last = "border-bottom:none;" if i == len(menu) - 1 else ""
    href = "AG-Sobre.dc.html" if label == "Sobre la audioguía" else "AG-Cuenta.dc.html"
    value = f'<span style="font-size:12.5px;color:{FG3};">{val}</span>' if val else ""
    menu_html += f'''        <a href="{href}" style="width:100%;display:flex;align-items:center;gap:12px;padding:14px 15px;border-bottom:1px solid {BORDER};{last}color:{FG2};text-decoration:none;box-sizing:border-box;">
          <span style="color:{GREEN};display:flex;">{ic(icn, 18)}</span>
          <span style="flex:1;font-size:14px;font-weight:700;color:{FG1};">{label}</span>
          {value}
          {ic('chevron-right', 16)}
        </a>\n'''

cuenta_scroll = f'''    <section style="padding:24px 16px 0;">
      <div style="background:{NAVY};border-radius:12px;padding:18px;color:#fff;box-sizing:border-box;">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
          <span style="width:44px;height:44px;border-radius:999px;background:rgba(79,181,108,0.18);border:1px solid rgba(79,181,108,0.4);display:flex;align-items:center;justify-content:center;color:{CYAN};flex:none;">{ic('account', 22)}</span>
          <div>
            <div style="font-size:17px;font-weight:800;">Estás como invitado</div>
            <div style="font-size:12.5px;color:{ON_DARK_2};margin-top:2px;">Escuchar recorridos no necesita cuenta.</div>
          </div>
        </div>
        <a href="AG-Cuenta.dc.html" style="display:flex;align-items:center;justify-content:center;gap:8px;background:#fff;color:{NAVY};border-radius:999px;padding:12px;font-size:14px;font-weight:700;text-decoration:none;box-sizing:border-box;">Iniciar sesión</a>
      </div>
    </section>
    <section style="padding:24px 16px 0;">
      {eyebrow('Para editores', 12)}
      <div style="background:#fff;border:1px dashed {CYAN_LINE};border-radius:12px;padding:16px;box-sizing:border-box;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
          <span style="width:36px;height:36px;border-radius:999px;background:{CYAN_SOFT};display:flex;align-items:center;justify-content:center;color:{CYAN_INK};flex:none;">{ic('lock', 18, 2.1)}</span>
          <div style="font-size:14px;font-weight:700;color:{FG1};">Grabar y publicar recorridos</div>
        </div>
        <p style="margin:0 0 12px;font-size:12.5px;line-height:1.55;color:{FG2};">Con una cuenta de editor vas a poder cargar puntos, grabar los audios en el lugar y publicar el recorrido para todo el público.</p>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <span style="display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:{MUTED};background:{PAGE};border:1px solid {BORDER};border-radius:999px;padding:7px 12px;">{ic('plus', 14, 2.2)}Nuevo recorrido</span>
          <span style="display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:{MUTED};background:{PAGE};border:1px solid {BORDER};border-radius:999px;padding:7px 12px;">{ic('map-pin', 14, 2.2)}Cargar puntos</span>
          <span style="display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:{MUTED};background:{PAGE};border:1px solid {BORDER};border-radius:999px;padding:7px 12px;">{ic('headphones', 14, 2.2)}Grabar audios</span>
        </div>
      </div>
    </section>
    <section style="padding:24px 16px 0;">
      {eyebrow('Ajustes', 12)}
      <div style="background:#fff;border:1px solid {BORDER};border-radius:8px;overflow:hidden;">
{menu_html}      </div>
    </section>
    <p style="text-align:center;font-size:11px;color:{MUTED};padding:24px 16px;margin:0;">audioguia.io · versión 1.2.2</p>'''

(OUT / "AG-Cuenta.dc.html").write_text(page(
    "audioguia.io — Cuenta", header() + "\n" + scroll(cuenta_scroll) + "\n" + nav("account")))

print("total:", round(TOTAL_M), "m ·", fmt_km(TOTAL_M), "· hecho:", fmt_km(DONE_M))
print("written:", sorted(p.name for p in OUT.glob("AG-*.dc.html")))

# --- 9. Recorrido en curso con la foto del punto ----------------------------
# La foto tapa el mapa y la barra de avance. Al llegar al punto no hace falta el
# mapa: ya estás ahí. Lo que sí hace falta es que el acompañante identifique el
# objeto del que habla el relato. Va en "contain" sobre fondo oscuro para que se
# vea el objeto entero, no un recorte.
PT07_FOTO = "/_blob/8ea021d8a50a0efc00485bd64f963461"

# La foto entra como una postal sobre el mapa, que queda atrás bajo un velo.
# Regla de tamaño: la foto se escala hasta tocar el lado que la limita y lo pasa
# 4 px para cada lado, así se lee como algo apoyado encima y no como un recorte
# del mapa. Foto vertical: se pasa arriba y abajo. Foto apaisada: izquierda y
# derecha. Foto del mismo ratio que el hueco: lo tapa entero.
# Una sola foto por punto.
PHOTO_RATIO = 450 / 600     # ancho sobre alto de la foto del punto 07
FRAME, OVERHANG = 9, 4      # marco blanco, y cuánto se pasa del mapa por lado

VELO = '''
    <div aria-hidden="true" style="position:absolute;inset:0;background:rgba(11,32,51,0.58);"></div>'''


def postal_size(box_w, box_h, ratio=PHOTO_RATIO, frame=FRAME, out=OVERHANG):
    h = box_h + 2 * out
    w = round((h - 2 * frame) * ratio) + 2 * frame
    if w > box_w + 2 * out:                       # la limita el ancho, no el alto
        w = box_w + 2 * out
        h = round((w - 2 * frame) / ratio) + 2 * frame
    return w, h


def foto_map(map_h, map_w=None, labels=True, x=21, close=44):
    """Mapa con velo y la foto del punto encima, como postal."""
    w, h = postal_size(map_w or MAP_W, map_h)
    top = -(h - map_h) // 2
    return f'''  <div style="position:relative;flex:none;">
{map_panel(map_h, labels=labels, width=map_w, crosshair=False, over=VELO)}
    <div style="position:absolute;top:{top}px;left:50%;transform:translateX(-50%);width:{w}px;height:{h}px;">
      <img src="{PT07_FOTO}" alt="Cartel del Parque Nacional Nahuel Huapi titulado Hábiles Carpinteros, con la ficha del Carpintero Gigante." style="width:100%;height:100%;object-fit:cover;display:block;border:{FRAME}px solid #fff;box-sizing:border-box;border-radius:2px;box-shadow:0 12px 30px rgba(0,0,0,0.6);cursor:pointer;">
      <button type="button" aria-label="Cerrar la foto del punto" style="position:absolute;top:-{close // 3}px;right:-{close // 3}px;width:{close}px;height:{close}px;display:flex;align-items:center;justify-content:center;background:#fff;border:none;border-radius:50%;cursor:pointer;color:{NAVY};box-shadow:0 3px 12px rgba(0,0,0,0.55);">{ic('x', x, 2.6)}</button>
    </div>
  </div>'''

foto_body = f'''  <div style="flex:1;min-height:0;display:flex;flex-direction:column;padding:8px 16px 14px;box-sizing:border-box;">
{foto_map(300)}
    <div style="height:18px;flex:none;"></div>
{trail_progress()}
    <div style="height:18px;flex:none;"></div>
{current_point_card(16, foto_open=True)}
{scrubber}
{transport}
{stop_btn}
  </div>'''

(OUT / "AG-Recorrido-Foto.dc.html").write_text(page(
    "audioguia.io — Recorrido con foto del punto",
    run_bar + "\n" + foto_body + "\n" + nav_inverted(), NAVY))
