#!/usr/bin/env python3
"""Landscape (phone) and tablet layouts for audioguia.io.

Imports gen_ag, which also rewrites the portrait screens. That is harmless and
keeps one single source for colours, icons, the map and the trail data.
"""
from gen_ag import *   # noqa: F401,F403
from gen_ag import (OUT, W, H, NAVY, NAVY_PANEL, GREEN, GPS, CYAN, CYAN_INK, CYAN_SOFT,
                    CYAN_LINE, PAGE, BORDER, FG1, FG2, FG3, MUTED, ON_DARK_2, ON_DARK_3,
                    LOGO_H, LOGO_H_WHITE, ICON, PHOTO, MERCH, GREEN_CTA,
                    BG_CASCADA, BG_ARRAYANES, BG_HASBURGO, PT007,
                    ic, mark, eyebrow, map_panel, fmt_km, DONE_M, TOTAL_M,
                    POINTS, CUM, OFFLINE_CHIP, DOT, foto_map, foto_toggle, ampliar_btn,
                    trail_progress, current_point_card)

LW, LH = 932, 430          # phone, landscape
TW, TH = 1194, 834         # tablet, landscape (iPad 11")

NAV_ITEMS = [("home", "Inicio", "AGH-Inicio.dc.html"), ("compass", "Explorar", "AGH-Explorar.dc.html"),
             ("download", "Offline", "AGH-Offline.dc.html"), ("account", "Cuenta", "AGH-Cuenta.dc.html")]


def page_l(title, body, w, h, bg="#fff"):
    return f'''<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;0,900;1,400&amp;display=swap">
<style>
body{{margin:0;font-family:'Lato','Helvetica Neue',Calibri,Arial,sans-serif;background:#e8edf1;color:{FG1};-webkit-font-smoothing:antialiased}}
a{{color:inherit}}
button{{font-family:'Lato','Helvetica Neue',Calibri,Arial,sans-serif}}
</style>
</helmet>
<div style="width:{w}px;height:{h}px;box-sizing:border-box;position:relative;display:flex;background:{bg};overflow:hidden;font-family:'Lato','Helvetica Neue',Calibri,Arial,sans-serif;color:{FG1};">
{body}
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{{"$preview":{{"width":{w},"height":{h}}}}}'>
class Component extends DCLogic {{
  renderVals() {{
    return {{}};
  }}
}}
</script>
</body>
</html>
'''


def rail(active, width=76, tablet=False, dark=False):
    """Bottom bar becomes a left rail: in landscape the height is the scarce
    resource, and the thumbs sit at the sides."""
    items = []
    for name, label, href in NAV_ITEMS:
        on = name == active
        col = (CYAN if on else ON_DARK_3) if dark else (CYAN_INK if on else MUTED)
        bg = (f"background:rgba(79,181,108,0.14);" if on else "") if dark else (f"background:{CYAN_SOFT};" if on else "")
        cur = ' aria-current="page"' if on else ""
        items.append(
            f'      <a href="{href}"{cur} style="display:flex;flex-direction:column;align-items:center;justify-content:center;'
            f'gap:3px;color:{col};text-decoration:none;width:{width - 16}px;padding:8px 0;border-radius:10px;{bg}">'
            f'{ic(name, 21, 2.4 if on else 2)}<span style="font-size:9.5px;font-weight:{700 if on else 600};">{label}</span></a>')
    skin = (f"background:#0B2033;border-right:1px solid rgba(255,255,255,0.10);" if dark
            else f"background:#fff;border-right:1px solid {BORDER};")
    return f'''  <nav aria-label="Navegación principal" style="width:{width}px;flex:none;{skin}display:flex;flex-direction:column;align-items:center;justify-content:center;padding:14px 0;box-sizing:border-box;">
    <div style="display:flex;flex-direction:column;gap:6px;align-items:center;">
{chr(10).join(items)}
    </div>
  </nav>'''


def body(inner, bg=PAGE, pad="20px"):
    return (f'  <div style="flex:1;min-width:0;min-height:0;overflow-y:auto;overflow-x:hidden;'
            f'background:{bg};padding:{pad};box-sizing:border-box;">\n{inner}\n  </div>')


# --- compact trail card, two per row --------------------------------------
def card(img, title, meta, difficulty, offline=False):
    chip = f'<div style="margin-top:6px;">{OFFLINE_CHIP}</div>' if offline else ""
    return f'''      <div style="display:flex;gap:11px;align-items:flex-start;background:#fff;border:1px solid {BORDER};border-radius:8px;padding:12px;box-shadow:0 1px 2px rgba(16,44,68,0.06);box-sizing:border-box;">
        <a href="AGH-Detalle.dc.html" style="display:flex;gap:11px;align-items:flex-start;flex:1;min-width:0;text-decoration:none;color:inherit;">
          <img src="{img}" alt="" style="width:58px;height:58px;flex:none;border-radius:6px;object-fit:cover;">
          <div style="flex:1;min-width:0;">
            <div style="font-size:13.5px;font-weight:700;color:{FG1};line-height:1.25;margin-bottom:6px;">{title}</div>
            <div style="margin-bottom:5px;">{mark(difficulty)}</div>
            <div style="display:flex;align-items:center;gap:6px;font-size:11px;color:{FG3};flex-wrap:wrap;">{meta}</div>
            {chip}
          </div>
        </a>
        <div style="display:flex;flex-direction:column;gap:6px;flex:none;align-items:center;">
          <a href="AGH-Recorrido.dc.html" aria-label="Iniciar recorrido" style="width:34px;height:34px;display:flex;align-items:center;justify-content:center;background:{PAGE};border:1px solid {BORDER};border-radius:50%;color:{GREEN};">{ic('play', 14)}</a>
          <button type="button" aria-label="Descargar" style="width:34px;height:34px;display:flex;align-items:center;justify-content:center;background:{CYAN_SOFT if offline else PAGE};border:1px solid {CYAN_LINE if offline else BORDER};border-radius:50%;cursor:pointer;color:{CYAN_INK if offline else FG2};">{ic('download', 14)}</button>
        </div>
      </div>'''


C_CASCADA = card(BG_CASCADA, "Cascada de los Duendes",
                 f'<span>0,52 km</span>{DOT}<span>10 puntos</span>{DOT}<span>a ~740 m</span>', "Sendero fácil", True)
C_ARRAYANES = card(BG_ARRAYANES, "Sendero de los Arrayanes",
                   f'<span>1,45 km</span>{DOT}<span>18 puntos</span>{DOT}<span>a ~3,4 km</span>', "Sendero fácil")
C_HASBURGO = card(BG_HASBURGO, "Sendero a la Piedra de Hasburgo",
                  f'<span>1,71 km</span>{DOT}<span>17 puntos</span>{DOT}<span>a ~8,1 km</span>', "Sendero exigente")

SEARCH_CTA = f'''          <div style="background:{GREEN_CTA};border-radius:12px;padding:16px;box-sizing:border-box;">
            <label for="q" style="display:block;font-size:11px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:#CFE8D8;margin-bottom:10px;">Buscá un recorrido</label>
            <div style="display:flex;align-items:center;gap:10px;background:#fff;border-radius:8px;padding:13px 14px;box-sizing:border-box;margin-bottom:10px;">
              <span style="color:{GREEN};display:flex;flex:none;">{ic('search', 19)}</span>
              <input id="q" type="search" placeholder="Sendero, lugar o tema" style="flex:1;min-width:0;border:none;outline:none;background:transparent;font-family:inherit;font-size:14.5px;color:{FG1};">
            </div>
            <a href="AGH-Explorar.dc.html" style="display:flex;align-items:center;justify-content:center;gap:8px;border:1.5px solid rgba(255,255,255,0.5);border-radius:999px;padding:12px;color:#fff;font-size:14.5px;font-weight:700;text-decoration:none;box-sizing:border-box;">Explorar todos los recorridos {ic('chevron-right', 16)}</a>
          </div>'''

# --- 1. Inicio --------------------------------------------------------------
inicio = f'''    <div style="padding:20px;">
      <div style="display:flex;gap:24px;align-items:flex-start;">
        <div style="flex:1;min-width:0;">
          <img src="{LOGO_H}" alt="audioguia.io" style="width:212px;height:53px;object-fit:contain;display:block;margin-bottom:12px;">
          <h1 style="margin:0 0 7px;font-size:24px;line-height:1.15;font-weight:900;color:{FG1};letter-spacing:-0.015em;">Senderos para escuchar</h1>
          <p style="margin:0 0 9px;font-size:13.5px;line-height:1.55;color:{FG2};">Una audioguía accesible para recorrer senderos naturales a través del sonido. Los relatos se activan solos a medida que caminás.</p>
          <p style="margin:0 0 9px;font-size:13.5px;line-height:1.55;color:{FG2};">Los senderos se caminan acompañados: la app guía con imágenes a quien acompaña, y el relato y las señales sonoras acompañan a quienes escuchan.</p>
          <a href="AGH-Sobre.dc.html" style="display:inline-flex;align-items:center;gap:6px;font-size:13.5px;font-weight:700;color:{CYAN_INK};text-decoration:none;margin-bottom:14px;">Cómo funciona {ic('chevron-right', 15)}</a>
{SEARCH_CTA}
        </div>
        <div style="flex:1;min-width:0;">
          <div style="border-radius:12px;overflow:hidden;">
            <img src="{PHOTO}" alt="Dos personas caminando por una pasarela de madera en el bosque, una de ellas con bastón blanco." style="width:100%;height:390px;object-fit:cover;object-position:50% 31%;display:block;">
          </div>
        </div>
      </div>
    </div>
    <section style="background:#fff;border-top:1px solid {BORDER};">
      <div style="padding:20px 20px 16px;">
        {eyebrow('Tienda', 12)}
        <div style="font-size:17px;font-weight:700;color:{FG1};margin-bottom:6px;">Gorras, remeras, tazas y biromes</div>
        <p style="margin:0 0 12px;font-size:13px;line-height:1.55;color:{FG2};max-width:560px;">Con el logo de audioguia.io. [QUÉ CONTAMOS ACÁ SOBRE LA TIENDA: a dónde va lo recaudado, envíos, dónde se retira.]</p>
        <a href="AGH-Inicio.dc.html" style="display:inline-flex;align-items:center;gap:6px;font-size:13.5px;font-weight:700;color:{CYAN_INK};text-decoration:none;">Ver la tienda {ic('chevron-right', 15)}</a>
      </div>
      <img src="{MERCH}" alt="Gorra, taza, remera y birome con el logo de audioguia.io." style="width:100%;height:auto;display:block;">
    </section>'''

(OUT / "AGH-Inicio.dc.html").write_text(page_l(
    "audioguia.io — Inicio horizontal", rail("home") + "\n" + body(inicio, "#fff", "0"), LW, LH))

# --- 2. Explorar ------------------------------------------------------------
explorar = f'''    <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:12px;">
      <h2 style="margin:0;font-size:21px;font-weight:900;color:{FG1};letter-spacing:-0.01em;">Explorar</h2>
      <div style="display:flex;gap:7px;align-items:center;">
        <button type="button" aria-pressed="true" style="display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:700;color:{CYAN_INK};background:{CYAN_SOFT};border:1px solid {CYAN_LINE};border-radius:999px;padding:6px 12px;cursor:pointer;">{ic('map-pin', 13, 2.2)}Cerca mío</button>
        <button type="button" style="font-size:12px;font-weight:700;color:{FG1};background:#fff;border:1px solid {BORDER};border-radius:999px;padding:6px 12px;cursor:pointer;">Más cortos</button>
        <button type="button" style="font-size:12px;font-weight:700;color:{FG1};background:#fff;border:1px solid {BORDER};border-radius:999px;padding:6px 12px;cursor:pointer;">Accesibles</button>
        <button type="button" style="font-size:12px;font-weight:700;color:{FG1};background:#fff;border:1px solid {BORDER};border-radius:999px;padding:6px 12px;cursor:pointer;">Descargados</button>
        <button type="button" aria-label="Buscar" style="width:34px;height:34px;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid {BORDER};border-radius:999px;cursor:pointer;color:{FG1};">{ic('search', 16)}</button>
      </div>
    </div>
    <div style="font-size:11.5px;color:{FG3};font-weight:600;margin-bottom:10px;">3 recorridos · ordenados por distancia</div>
    <div style="display:grid;grid-template-columns:repeat(2, minmax(0, 1fr));gap:12px;">
{C_CASCADA}
{C_ARRAYANES}
{C_HASBURGO}
      <div style="display:flex;align-items:center;justify-content:center;background:#fff;border:1px dashed {BORDER};border-radius:8px;padding:14px;box-sizing:border-box;">
        <p style="margin:0;font-size:12px;line-height:1.5;color:{FG3};text-align:center;">Descargá el recorrido antes de salir del Wi-Fi o de una buena conexión de datos.</p>
      </div>
    </div>'''

(OUT / "AGH-Explorar.dc.html").write_text(page_l(
    "audioguia.io — Explorar horizontal", rail("compass") + "\n" + body(explorar), LW, LH))

# --- 3. Offline -------------------------------------------------------------
offline = f'''    <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:12px;">
      <h2 style="margin:0;font-size:21px;font-weight:900;color:{FG1};letter-spacing:-0.01em;">Offline</h2>
      <div style="display:flex;align-items:center;gap:12px;background:{CYAN_SOFT};border:1px solid {CYAN_LINE};border-radius:8px;padding:8px 12px;">
        <span style="display:flex;color:{CYAN_INK};">{ic('download', 16, 2.2)}</span>
        <span style="font-size:12.5px;font-weight:700;color:{CYAN_INK};">1 recorrido descargado · 11,59 MB</span>
        <button type="button" style="background:none;border:none;cursor:pointer;color:{CYAN_INK};font-size:12px;font-weight:700;text-decoration:underline;">Liberar</button>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(2, minmax(0, 1fr));gap:12px;">
{C_CASCADA}
      <div style="background:#fff;border:1px solid {BORDER};border-radius:10px;padding:14px 15px;box-sizing:border-box;">
        <div style="font-size:13px;font-weight:700;color:{FG1};margin-bottom:5px;">Los descargados funcionan sin señal</div>
        <p style="margin:0 0 10px;font-size:12.5px;line-height:1.55;color:{FG2};">Quedan guardados los audios, las fotos y el mapa del recorrido. El GPS del teléfono sigue funcionando sin datos.</p>
        <a href="AGH-Explorar.dc.html" style="display:inline-flex;align-items:center;gap:6px;font-size:13px;font-weight:700;color:{CYAN_INK};text-decoration:none;">Descargar otro recorrido {ic('chevron-right', 15)}</a>
      </div>
    </div>'''

(OUT / "AGH-Offline.dc.html").write_text(page_l(
    "audioguia.io — Offline horizontal", rail("download") + "\n" + body(offline), LW, LH))

# --- 4. Detalle -------------------------------------------------------------
detalle = f'''  <div style="width:330px;flex:none;position:relative;background:#0b1f14;">
    <img src="{BG_CASCADA}" alt="" style="width:100%;height:100%;object-fit:cover;display:block;">
    <a href="AGH-Explorar.dc.html" aria-label="Volver" style="position:absolute;top:14px;left:14px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;background:rgba(16,44,68,0.72);border-radius:999px;color:#fff;text-decoration:none;">{ic('chevron-left', 18)}</a>
  </div>
  <div style="flex:1;min-width:0;min-height:0;overflow-y:auto;overflow-x:hidden;background:#fff;padding:20px;box-sizing:border-box;">
    <div style="display:flex;align-items:center;gap:9px;margin-bottom:12px;flex-wrap:wrap;">{mark('Sendero fácil')}{OFFLINE_CHIP}</div>
    <h1 style="margin:0 0 9px;font-size:23px;line-height:1.18;font-weight:900;color:{FG1};letter-spacing:-0.015em;">Cascada de los Duendes</h1>
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:13px;font-size:12px;color:{FG3};flex-wrap:wrap;">
      <span>Bariloche</span><span style="width:3px;height:3px;border-radius:50%;background:{MUTED};"></span><span>{fmt_km(TOTAL_M)}</span><span style="width:3px;height:3px;border-radius:50%;background:{MUTED};"></span><span>10 puntos</span><span style="width:3px;height:3px;border-radius:50%;background:{MUTED};"></span><span>11,59 MB</span>
    </div>
    <div style="display:flex;gap:10px;margin-bottom:16px;">
      <a href="AGH-Recorrido.dc.html" style="flex:1;display:flex;align-items:center;justify-content:center;gap:11px;background:{NAVY};border-radius:10px;padding:14px;color:#fff;box-shadow:0 8px 20px rgba(16,44,68,0.24);box-sizing:border-box;text-decoration:none;">
        <span style="width:32px;height:32px;flex:none;display:flex;align-items:center;justify-content:center;background:rgba(79,181,108,0.24);border-radius:50%;color:{CYAN};">{ic('play', 15)}</span>
        <span style="font-size:15px;font-weight:800;">Iniciar recorrido</span>
      </a>
      <button type="button" aria-label="Favorito" style="width:50px;flex:none;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid {BORDER};border-radius:10px;cursor:pointer;color:{FG2};">{ic('heart', 19)}</button>
      <button type="button" aria-label="Descargado" style="width:50px;flex:none;display:flex;align-items:center;justify-content:center;background:{CYAN_SOFT};border:1px solid {CYAN_LINE};border-radius:10px;cursor:pointer;color:{CYAN_INK};">{ic('check', 19)}</button>
      <button type="button" aria-label="Compartir" style="width:50px;flex:none;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid {BORDER};border-radius:10px;cursor:pointer;color:{FG2};">{ic('share', 19)}</button>
    </div>
    <div style="display:flex;gap:24px;align-items:flex-start;">
      <div style="flex:1;min-width:0;">
        {eyebrow('Sobre este recorrido', 12)}
        <p style="margin:0 0 16px;font-size:13px;line-height:1.6;color:{FG1};">[DESCRIPCIÓN DEL RECORRIDO. Hoy el JSON del tour no la trae.]</p>
        {eyebrow('Antes de salir', 12)}
        <div style="display:flex;gap:9px;background:{PAGE};border:1px solid {BORDER};border-radius:8px;padding:11px 12px;box-sizing:border-box;">
          <span style="color:{GREEN};flex:none;display:flex;">{ic('headphones', 17, 2.1)}</span>
          <p style="margin:0;font-size:12px;line-height:1.55;color:{FG2};">Mantené la app abierta mientras caminás para que el GPS dispare los audios.</p>
        </div>
      </div>
    </div>
  </div>'''

(OUT / "AGH-Detalle.dc.html").write_text(page_l(
    "audioguia.io — Detalle horizontal", detalle, LW, LH))

# --- 5. Recorrido en curso --------------------------------------------------

# En horizontal el relato tiene su propio scrubber y su transporte, igual que en
# vertical. Antes esto era la lista de puntos.
def skip_btn(back, size=30):
    d = ('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"></path><path d="M3 4v4h4"></path>' if back
         else '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"></path><path d="M21 4v4h-4"></path>')
    n = "15" if back else "30"
    lab = "Retroceder 15 segundos" if back else "Adelantar 30 segundos"
    return (f'<button type="button" aria-label="{lab}" style="position:relative;width:40px;height:40px;'
            f'display:flex;align-items:center;justify-content:center;background:none;border:none;cursor:pointer;color:#fff;">'
            f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" '
            f'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{d}</svg>'
            f'<span style="position:absolute;font-size:8px;font-weight:800;">{n}</span></button>')


player_h = f'''        <div style="flex:1;min-height:0;display:flex;flex-direction:column;justify-content:center;gap:10px;">
          <div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:7px;">
              <span style="font-size:10px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:{ON_DARK_2};">Relato del punto 07</span>
              <span style="display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:700;color:{CYAN};"><span style="width:6px;height:6px;border-radius:999px;background:{CYAN};display:block;"></span>Reproduciendo</span>
            </div>
            <div role="slider" aria-label="Avance del relato" aria-valuemin="0" aria-valuemax="100" aria-valuenow="62" tabindex="0" style="position:relative;height:5px;border-radius:999px;background:rgba(255,255,255,0.18);">
              <div style="position:absolute;left:0;top:0;bottom:0;width:62%;border-radius:999px;background:{GREEN};"></div>
              <div style="position:absolute;top:50%;left:62%;transform:translate(-50%,-50%);width:14px;height:14px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,0.4);"></div>
            </div>
            <div style="display:flex;justify-content:space-between;margin-top:7px;font-size:11px;font-weight:600;">
              <span style="color:#fff;">1:12</span><span style="color:{ON_DARK_3};">-0:44</span>
            </div>
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <button type="button" aria-label="Velocidad de reproducción" style="display:flex;align-items:center;justify-content:center;min-width:38px;height:28px;padding:0 9px;background:rgba(255,255,255,0.12);border:none;border-radius:999px;color:#fff;font-size:11.5px;font-weight:700;cursor:pointer;">1×</button>
            {skip_btn(True)}
            <button type="button" aria-label="Pausar el relato" style="width:56px;height:56px;display:flex;align-items:center;justify-content:center;background:#fff;border:none;border-radius:50%;cursor:pointer;color:{NAVY};">{ic('pause', 23)}</button>
            {skip_btn(False)}
            <span aria-hidden="true" style="width:38px;flex:none;"></span>
          </div>
        </div>'''

recorrido = f'''  <div style="flex:1;min-width:0;display:flex;flex-direction:column;padding:10px 16px 14px;box-sizing:border-box;">
    <div style="flex:none;display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:10px;">
      <a href="AGH-Detalle.dc.html" aria-label="Volver al detalle" style="width:34px;height:34px;flex:none;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.1);border-radius:999px;color:#fff;text-decoration:none;">{ic('chevron-down', 18, 2.2)}</a>
      <div style="flex:1;min-width:0;display:flex;align-items:center;gap:10px;">
        <span style="display:inline-flex;align-items:center;gap:6px;font-size:10px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:{CYAN};flex:none;"><span style="width:6px;height:6px;border-radius:999px;background:{CYAN};display:block;"></span>En recorrido</span>
        <h1 style="margin:0;font-size:17px;font-weight:800;color:#fff;letter-spacing:-0.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">Cascada de los Duendes</h1>
      </div>
      <span style="display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:700;color:#fff;flex:none;font-variant-numeric:tabular-nums;">{ic('clock', 13, 2.2)}24:10</span>
      <button type="button" aria-label="Más opciones" style="width:34px;height:34px;flex:none;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.1);border:none;border-radius:999px;cursor:pointer;color:#fff;">{ic('more', 18)}</button>
    </div>

    <div style="flex:1;min-height:0;display:flex;gap:16px;">
{map_panel(348, width=462)}
      <div style="flex:1;min-width:0;display:flex;flex-direction:column;">
        <div style="display:flex;align-items:center;gap:11px;background:{NAVY_PANEL};border-radius:10px;padding:9px;margin-bottom:10px;box-sizing:border-box;flex:none;">
          <img src="{PT007}" alt="" style="width:46px;height:46px;border-radius:7px;object-fit:cover;flex:none;">
          <div style="flex:1;min-width:0;">
            <div style="font-size:9.5px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:{CYAN};margin-bottom:2px;">Punto 7 de 10 · a 6 m</div>
            <div style="font-size:15px;font-weight:700;color:#fff;line-height:1.2;">El Carpintero Gigante</div>
          </div>
          {foto_toggle(False, 38, 17)}
        </div>

{trail_progress()}
        <div style="height:10px;flex:none;"></div>
{player_h}

        <a href="AGH-Detalle.dc.html" style="flex:none;display:flex;align-items:center;justify-content:center;gap:8px;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:999px;padding:10px;color:#fff;font-size:13px;font-weight:700;text-decoration:none;box-sizing:border-box;">{ic('stop', 15)}Detener recorrido</a>
      </div>
    </div>
  </div>'''

(OUT / "AGH-Recorrido.dc.html").write_text(page_l(
    "audioguia.io — Recorrido horizontal", rail("compass", dark=True) + "\n" + recorrido, LW, LH, NAVY))

# --- 6. Sobre ---------------------------------------------------------------
def feature(icon, title, text):
    return f'''      <div style="display:flex;gap:11px;background:#fff;border:1px solid {BORDER};border-radius:10px;padding:13px 14px;box-sizing:border-box;">
        <span style="color:{GREEN};flex:none;display:flex;">{ic(icon, 19, 2.1)}</span>
        <div>
          <div style="font-size:13px;font-weight:700;color:{FG1};margin-bottom:3px;">{title}</div>
          <p style="margin:0;font-size:12px;line-height:1.5;color:{FG2};">{text}</p>
        </div>
      </div>'''


sobre = f'''    <a href="AGH-Inicio.dc.html" aria-label="Volver al inicio" style="width:38px;height:38px;display:flex;align-items:center;justify-content:center;background:{PAGE};border:1px solid {BORDER};border-radius:999px;color:{FG1};text-decoration:none;margin-bottom:16px;">{ic('chevron-left', 19)}</a>
    <div style="display:flex;gap:24px;align-items:flex-start;">
      <div style="flex:1;min-width:0;">
        <img src="{LOGO_H}" alt="audioguia.io" style="width:212px;height:53px;object-fit:contain;display:block;margin-bottom:12px;">
        <h1 style="margin:0 0 7px;font-size:23px;font-weight:900;color:{FG1};letter-spacing:-0.015em;">Senderos para escuchar</h1>
        <p style="margin:0 0 14px;font-size:13.5px;line-height:1.55;color:{FG2};">Una audioguía accesible para recorrer senderos naturales a través del sonido.</p>
        <div style="border-top:1px solid {BORDER};padding-top:12px;font-size:12px;color:{FG3};line-height:1.7;">
          <div><strong style="color:{FG2};">Proyecto:</strong> audioguia.io</div>
          <div><strong style="color:{FG2};">Última actualización:</strong> 2026-02-21</div>
          <div><strong style="color:{FG2};">Versión app:</strong> 1.2.2 · <strong style="color:{FG2};">contenidos:</strong> 2026.02.21</div>
        </div>
      </div>
      <div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:12px;">
{feature('accessibility', 'Pensada para escuchar', 'Está hecha para personas con discapacidad visual, y también para quienes quieran recorrer el entorno de otra manera.')}
{feature('map-pin', 'Los audios se disparan solos', 'Cuando te acercás a un punto de interés se reproduce el relato. También podés reproducirlos a mano.')}
{feature('download', 'Funciona sin conexión', 'Descargá el recorrido antes de salir y los audios quedan disponibles aunque no haya señal ni datos.')}
        <div style="padding-top:2px;">
          {eyebrow('Agradecimientos', 12)}
          <p style="margin:0;font-size:12.5px;line-height:1.55;color:{FG2};">Pablo, Yamila, Lucas, Karin, Andre, Guille, Lorenzo, Juan y Axel.</p>
        </div>
      </div>
    </div>'''

(OUT / "AGH-Sobre.dc.html").write_text(page_l(
    "audioguia.io — Sobre horizontal", rail("home") + "\n" + body(sobre), LW, LH))

# --- 7. Cuenta --------------------------------------------------------------
menu_h = [("download", "Descargas y espacio", "11,59 MB"), ("accessibility", "Accesibilidad y voz", None),
          ("share", "Compartir la app", None), ("map-pin", "Sobre la audioguía", None)]
menu_html_h = ""
for i, (icn, label, val) in enumerate(menu_h):
    last = "border-bottom:none;" if i == len(menu_h) - 1 else ""
    value = f'<span style="font-size:12px;color:{FG3};">{val}</span>' if val else ""
    menu_html_h += f'''        <a href="AGH-Cuenta.dc.html" style="display:flex;align-items:center;gap:11px;padding:12px 14px;border-bottom:1px solid {BORDER};{last}color:{FG2};text-decoration:none;box-sizing:border-box;">
          <span style="color:{GREEN};display:flex;">{ic(icn, 17)}</span>
          <span style="flex:1;font-size:13.5px;font-weight:700;color:{FG1};">{label}</span>
          {value}
          {ic('chevron-right', 15)}
        </a>\n'''

cuenta = f'''    <div style="display:flex;gap:24px;align-items:flex-start;">
      <div style="width:360px;flex:none;">
        <div style="background:{NAVY};border-radius:12px;padding:16px;color:#fff;box-sizing:border-box;margin-bottom:12px;">
          <div style="display:flex;align-items:center;gap:11px;margin-bottom:12px;">
            <span style="width:40px;height:40px;border-radius:999px;background:rgba(79,181,108,0.2);border:1px solid rgba(79,181,108,0.45);display:flex;align-items:center;justify-content:center;color:{CYAN};flex:none;">{ic('account', 20)}</span>
            <div>
              <div style="font-size:16px;font-weight:800;">Estás como invitado</div>
              <div style="font-size:12px;color:{ON_DARK_2};margin-top:2px;">Escuchar recorridos no necesita cuenta.</div>
            </div>
          </div>
          <a href="AGH-Cuenta.dc.html" style="display:flex;align-items:center;justify-content:center;background:#fff;color:{NAVY};border-radius:999px;padding:11px;font-size:13.5px;font-weight:700;text-decoration:none;box-sizing:border-box;">Iniciar sesión</a>
        </div>
        <div style="background:#fff;border:1px dashed {CYAN_LINE};border-radius:12px;padding:14px;box-sizing:border-box;">
          <div style="display:flex;align-items:center;gap:9px;margin-bottom:7px;">
            <span style="width:32px;height:32px;border-radius:999px;background:{CYAN_SOFT};display:flex;align-items:center;justify-content:center;color:{CYAN_INK};flex:none;">{ic('lock', 17, 2.1)}</span>
            <div style="font-size:13.5px;font-weight:700;color:{FG1};">Grabar y publicar recorridos</div>
          </div>
          <p style="margin:0 0 10px;font-size:12px;line-height:1.5;color:{FG2};">Con una cuenta de editor vas a poder cargar puntos, grabar los audios en el lugar y publicar el recorrido.</p>
          <div style="display:flex;gap:7px;flex-wrap:wrap;">
            <span style="display:inline-flex;align-items:center;gap:5px;font-size:11.5px;font-weight:700;color:{MUTED};background:{PAGE};border:1px solid {BORDER};border-radius:999px;padding:6px 11px;">{ic('plus', 13, 2.2)}Nuevo recorrido</span>
            <span style="display:inline-flex;align-items:center;gap:5px;font-size:11.5px;font-weight:700;color:{MUTED};background:{PAGE};border:1px solid {BORDER};border-radius:999px;padding:6px 11px;">{ic('map-pin', 13, 2.2)}Cargar puntos</span>
            <span style="display:inline-flex;align-items:center;gap:5px;font-size:11.5px;font-weight:700;color:{MUTED};background:{PAGE};border:1px solid {BORDER};border-radius:999px;padding:6px 11px;">{ic('headphones', 13, 2.2)}Grabar audios</span>
          </div>
        </div>
      </div>
      <div style="flex:1;min-width:0;">
        {eyebrow('Ajustes', 12)}
        <div style="background:#fff;border:1px solid {BORDER};border-radius:8px;overflow:hidden;">
{menu_html_h}        </div>
        <p style="text-align:center;font-size:11px;color:{MUTED};padding:14px 0 0;margin:0;">audioguia.io · versión 1.2.2</p>
      </div>
    </div>'''

(OUT / "AGH-Cuenta.dc.html").write_text(page_l(
    "audioguia.io — Cuenta horizontal", rail("account") + "\n" + body(cuenta), LW, LH))

# --- Tablet: two panes ------------------------------------------------------
def big_card(img, title, meta, difficulty, selected=False, offline=False):
    ring = f"border:2px solid {GREEN};" if selected else f"border:1px solid {BORDER};"
    chip = f'<div style="margin-top:7px;">{OFFLINE_CHIP}</div>' if offline else ""
    return f'''      <div style="display:flex;gap:13px;align-items:flex-start;background:#fff;{ring}border-radius:10px;padding:12px;box-shadow:0 1px 2px rgba(16,44,68,0.06);box-sizing:border-box;">
        <img src="{img}" alt="" style="width:72px;height:72px;flex:none;border-radius:7px;object-fit:cover;">
        <div style="flex:1;min-width:0;">
          <div style="font-size:15px;font-weight:700;color:{FG1};line-height:1.25;margin-bottom:7px;">{title}</div>
          <div style="margin-bottom:6px;">{mark(difficulty)}</div>
          <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:{FG3};flex-wrap:wrap;">{meta}</div>
          {chip}
        </div>
      </div>'''


tablet_list = f'''    <h2 style="margin:0 0 14px;font-size:26px;font-weight:900;color:{FG1};letter-spacing:-0.01em;">Explorar</h2>
    <div style="display:flex;align-items:center;gap:9px;background:{PAGE};border:1px solid {BORDER};border-radius:9px;padding:13px 15px;margin-bottom:14px;box-sizing:border-box;">
      <span style="color:{GREEN};display:flex;flex:none;">{ic('search', 19)}</span>
      <span style="font-size:14.5px;color:{MUTED};">Sendero, lugar o tema</span>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;">
      <button type="button" aria-pressed="true" style="display:inline-flex;align-items:center;gap:6px;font-size:12.5px;font-weight:700;color:{CYAN_INK};background:{CYAN_SOFT};border:1px solid {CYAN_LINE};border-radius:999px;padding:7px 13px;cursor:pointer;">{ic('map-pin', 14, 2.2)}Cerca mío</button>
      <button type="button" style="font-size:12.5px;font-weight:700;color:{FG1};background:#fff;border:1px solid {BORDER};border-radius:999px;padding:7px 13px;cursor:pointer;">Más cortos</button>
      <button type="button" style="font-size:12.5px;font-weight:700;color:{FG1};background:#fff;border:1px solid {BORDER};border-radius:999px;padding:7px 13px;cursor:pointer;">Accesibles</button>
    </div>
    <div style="font-size:12px;color:{FG3};font-weight:600;margin-bottom:10px;">3 recorridos · ordenados por distancia</div>
    <div style="display:flex;flex-direction:column;gap:10px;">
{big_card(BG_CASCADA, "Cascada de los Duendes", f'<span>0,52 km</span>{DOT}<span>10 puntos</span>{DOT}<span>a ~740 m</span>', "Sendero fácil", selected=True, offline=True)}
{big_card(BG_ARRAYANES, "Sendero de los Arrayanes", f'<span>1,45 km</span>{DOT}<span>18 puntos</span>{DOT}<span>a ~3,4 km</span>', "Sendero fácil")}
{big_card(BG_HASBURGO, "Sendero a la Piedra de Hasburgo", f'<span>1,71 km</span>{DOT}<span>17 puntos</span>{DOT}<span>a ~8,1 km</span>', "Sendero exigente")}
    </div>'''

tablet_explorar = f'''{rail("compass", 92, True)}
  <div style="width:420px;flex:none;min-height:0;overflow-y:auto;overflow-x:hidden;background:{PAGE};border-right:1px solid {BORDER};padding:24px;box-sizing:border-box;">
{tablet_list}
  </div>
  <div style="flex:1;min-width:0;min-height:0;overflow-y:auto;overflow-x:hidden;background:#fff;">
    <div style="position:relative;height:260px;background:#0b1f14;">
      <img src="{BG_CASCADA}" alt="" style="width:100%;height:100%;object-fit:cover;display:block;">
    </div>
    <div style="padding:24px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:11px;flex-wrap:wrap;">{mark('Sendero fácil')}{OFFLINE_CHIP}</div>
      <h1 style="margin:0 0 11px;font-size:30px;line-height:1.15;font-weight:900;color:{FG1};letter-spacing:-0.015em;">Cascada de los Duendes</h1>
      <div style="display:flex;align-items:center;gap:9px;margin-bottom:16px;font-size:13px;color:{FG3};flex-wrap:wrap;">
        <span>Bariloche</span><span style="width:3px;height:3px;border-radius:50%;background:{MUTED};"></span><span>{fmt_km(TOTAL_M)}</span><span style="width:3px;height:3px;border-radius:50%;background:{MUTED};"></span><span>10 puntos</span><span style="width:3px;height:3px;border-radius:50%;background:{MUTED};"></span><span>11,59 MB</span>
      </div>
      <div style="display:flex;gap:10px;margin-bottom:20px;">
        <a href="AGT-Recorrido.dc.html" style="display:flex;align-items:center;justify-content:center;gap:12px;background:{NAVY};border-radius:10px;padding:16px 26px;color:#fff;box-shadow:0 10px 24px rgba(16,44,68,0.24);text-decoration:none;">
          <span style="width:34px;height:34px;flex:none;display:flex;align-items:center;justify-content:center;background:rgba(79,181,108,0.24);border-radius:50%;color:{CYAN};">{ic('play', 16)}</span>
          <span style="font-size:16px;font-weight:800;">Iniciar recorrido</span>
        </a>
        <button type="button" aria-label="Favorito" style="width:54px;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid {BORDER};border-radius:10px;cursor:pointer;color:{FG2};">{ic('heart', 20)}</button>
        <button type="button" aria-label="Descargado" style="width:54px;display:flex;align-items:center;justify-content:center;background:{CYAN_SOFT};border:1px solid {CYAN_LINE};border-radius:10px;cursor:pointer;color:{CYAN_INK};">{ic('check', 20)}</button>
        <button type="button" aria-label="Compartir" style="width:54px;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid {BORDER};border-radius:10px;cursor:pointer;color:{FG2};">{ic('share', 20)}</button>
      </div>
      <div style="display:flex;gap:24px;align-items:flex-start;">
        <div style="flex:1;min-width:0;">
          {eyebrow('Sobre este recorrido', 12)}
          <p style="margin:0 0 20px;font-size:14px;line-height:1.6;color:{FG1};">[DESCRIPCIÓN DEL RECORRIDO. Hoy el JSON del tour no la trae: hay que agregar un campo de texto por recorrido.]</p>
          {eyebrow('Antes de salir', 12)}
          <div style="display:flex;gap:10px;background:{PAGE};border:1px solid {BORDER};border-radius:8px;padding:13px 14px;box-sizing:border-box;">
            <span style="color:{GREEN};flex:none;display:flex;">{ic('headphones', 18, 2.1)}</span>
            <p style="margin:0;font-size:12.5px;line-height:1.55;color:{FG2};">Mantené la app abierta mientras caminás para que el GPS dispare los audios. Si el teléfono bloquea la pantalla, se pausa el seguimiento.</p>
          </div>
        </div>
      </div>
    </div>
  </div>'''

(OUT / "AGT-Explorar.dc.html").write_text(page_l(
    "audioguia.io — Explorar en tableta", tablet_explorar, TW, TH))

tablet_recorrido = f'''{rail("compass", 92, True, dark=True)}
  <div style="flex:1;min-width:0;display:flex;flex-direction:column;padding:20px 24px 24px;box-sizing:border-box;">
    <div style="flex:none;display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:16px;">
      <a href="AGT-Explorar.dc.html" aria-label="Volver al detalle" style="width:40px;height:40px;flex:none;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.1);border-radius:999px;color:#fff;text-decoration:none;">{ic('chevron-down', 21, 2.2)}</a>
      <div style="flex:1;min-width:0;display:flex;align-items:center;gap:12px;">
        <span style="display:inline-flex;align-items:center;gap:7px;font-size:11px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:{CYAN};flex:none;"><span style="width:7px;height:7px;border-radius:999px;background:{CYAN};display:block;"></span>En recorrido</span>
        <h1 style="margin:0;font-size:22px;font-weight:800;color:#fff;letter-spacing:-0.01em;">Cascada de los Duendes</h1>
      </div>
      <span style="display:inline-flex;align-items:center;gap:6px;font-size:14px;font-weight:700;color:#fff;flex:none;font-variant-numeric:tabular-nums;">{ic('clock', 15, 2.2)}24:10</span>
      <button type="button" aria-label="Más opciones" style="width:40px;height:40px;flex:none;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.1);border:none;border-radius:999px;cursor:pointer;color:#fff;">{ic('more', 20)}</button>
    </div>
    <div style="flex:1;min-height:0;display:flex;gap:24px;">
      <div style="flex:none;display:flex;flex-direction:column;">
{map_panel(528, width=700)}
        <div style="height:16px;flex:none;"></div>
{trail_progress()}
      </div>
      <div style="flex:1;min-width:0;display:flex;flex-direction:column;">
        <img src="{PT007}" alt="" style="width:100%;aspect-ratio:3/4;border-radius:14px;object-fit:cover;display:block;flex:none;margin-bottom:16px;">
{current_point_card(20, btn=ampliar_btn(44, 20))}
        <div style="flex:1;min-height:0;display:flex;flex-direction:column;justify-content:center;gap:20px;">
          <div>
            <div role="slider" aria-label="Avance del relato" aria-valuemin="0" aria-valuemax="100" aria-valuenow="62" tabindex="0" style="position:relative;height:6px;border-radius:999px;background:rgba(255,255,255,0.18);">
              <div style="position:absolute;left:0;top:0;bottom:0;width:62%;border-radius:999px;background:{GREEN};"></div>
              <div style="position:absolute;top:50%;left:62%;transform:translate(-50%,-50%);width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,0.4);"></div>
            </div>
            <div style="display:flex;justify-content:space-between;margin-top:9px;font-size:12.5px;font-weight:600;">
              <span style="color:#fff;">1:12</span><span style="color:{ON_DARK_3};">-0:44</span>
            </div>
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <button type="button" aria-label="Velocidad de reproducción" style="display:flex;align-items:center;justify-content:center;min-width:44px;height:32px;padding:0 11px;background:rgba(255,255,255,0.12);border:none;border-radius:999px;color:#fff;font-size:13px;font-weight:700;cursor:pointer;">1×</button>
            {skip_btn(True, 34)}
            <button type="button" aria-label="Pausar el relato" style="width:68px;height:68px;display:flex;align-items:center;justify-content:center;background:#fff;border:none;border-radius:50%;cursor:pointer;color:{NAVY};">{ic('pause', 27)}</button>
            {skip_btn(False, 34)}
            <span aria-hidden="true" style="width:44px;flex:none;"></span>
          </div>
        </div>
        <div style="height:20px;flex:none;"></div>
        <a href="AGT-Explorar.dc.html" style="flex:none;display:flex;align-items:center;justify-content:center;gap:9px;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:999px;padding:13px;color:#fff;font-size:14px;font-weight:700;text-decoration:none;box-sizing:border-box;">{ic('stop', 16)}Detener recorrido</a>
      </div>
    </div>
  </div>'''

(OUT / "AGT-Recorrido.dc.html").write_text(page_l(
    "audioguia.io — Recorrido en tableta", tablet_recorrido, TW, TH, NAVY))

print("horizontales:", sorted(p.name for p in OUT.glob("AGH-*.dc.html")))
print("tableta:", sorted(p.name for p in OUT.glob("AGT-*.dc.html")))


# --- 7. Recorrido en curso con la foto del punto ----------------------------
# Mismo cuerpo que el recorrido en curso: solo cambia el mapa, que pasa a tener
# velo y la postal encima. Así el mapa de base queda funcional en su artboard.
(OUT / "AGH-Recorrido-Foto.dc.html").write_text(page_l(
    "audioguia.io — Recorrido horizontal con foto",
    rail("compass", dark=True) + "\n" + recorrido.replace(
        map_panel(348, width=462), foto_map(348, 462, x=18, close=38)).replace(
        foto_toggle(False, 38, 17), foto_toggle(True, 38, 17)),
    LW, LH, NAVY))

# La tableta no lleva versión con foto: el panel derecho ya muestra la foto del
# punto arriba del título, así que el popup sobre el mapa sería repetir lo mismo.

print("con foto:", sorted(p.name for p in OUT.glob("AG*-Recorrido-Foto.dc.html")))
