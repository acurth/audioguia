# Tableta · Inicio, sin tienda

Maqueta de la home de audioguia.io en tableta apaisada, **1194 x 834**.
`index.html` es autónomo: abrilo en el navegador y se ve tal cual va.

Es una maqueta con estilos inline, no código de producción. Sirve como referencia
exacta de medidas y colores. Los comentarios de código del proyecto van en inglés.

## La estructura, que es lo importante

Tres bloques en fila, de izquierda a derecha:

1. **Riel de navegación, 92 px fijos.** Cuatro pestañas, Inicio · Explorar · Offline ·
   Cuenta, centradas verticalmente. En tableta y en teléfono acostado la navegación es
   este riel, no la barra de abajo.
2. **Panel de intro, 420 px fijos**, fondo `#F5F8FA`, borde derecho `#DCE4EB`.
   Isologo, título, los dos párrafos, "Cómo funciona", y el bloque verde con el buscador
   y el botón Explorar. Abajo de todo, separado por una línea, el pie con la cantidad de
   recorridos y la fecha de actualización.
3. **Panel de imagen, el resto del ancho.** La foto ocupa el panel entero, de borde a
   borde y de arriba a abajo. Sin margen, sin bordes redondeados, sin blanco debajo.

Esa proporción de 1 a 3 entre los dos paneles es la misma que usa la pantalla de Explorar,
y es lo que hace que las dos se sientan la misma app.

## Anchos máximos, para que no se despatarre en un monitor grande

Son dos topes, uno adentro del otro:

- **La app entera se topea en 1440 px y se centra.** Más allá quedan márgenes a los
  costados, no más contenido.
- El panel de intro **nunca crece**: queda en 420 px siempre. Todo el ancho extra se lo
  lleva el panel de la foto.

Con los 1194 px de la tableta ninguno de los dos topes se nota. Están para el caso de
abrirla en una computadora.

## El recorte de la foto

La foto original es vertical, 665 x 1182, y el panel es de proporción más ancha. Con
`object-fit: cover` el recorte se come alto y no ancho, así que las dos personas caminando
no se pierden por los costados. El `object-position` va en `50% 35%`.

## Por qué la foto ocupa todo el panel

Es la respuesta a "solo tengo la foto por ahora". Si la foto se queda en 470 px de alto,
abajo queda un blanco que se lee como que falta algo. A sangre completa, el panel se lee
como una imagen de portada y la pantalla queda en dos bloques con trabajos distintos:
a la izquierda se explica y se ofrece la acción, a la derecha se muestra de qué se trata.

Cuando exista la sección de tienda, la foto vuelve a 470 px de alto y la tienda va debajo,
dentro del mismo panel derecho con scroll propio. **El panel izquierdo no se toca.**

## Colores usados acá

| Uso | Valor |
|---|---|
| Fondo del panel de intro | `#F5F8FA` |
| Bordes | `#DCE4EB` |
| Títulos y texto fuerte | `#102C44` |
| Texto de párrafo | `#44586B` |
| Texto chico y pie | `#9AA8B4` |
| Bloque CTA verde | `#2A7440` |
| Links y detalles sobre blanco | `#2A7440` |
| Verde de íconos | `#348E4E` |
| Tipografía | Lato, pesos 400, 700, 900 |

Nota de contraste: el verde de marca `#348E4E` da 4,10:1 sobre blanco y **no llega al
mínimo AA**. Por eso el texto chico usa `#2A7440`, que da 5,72:1. Esta app la usa gente con
baja visión, así que ese piso no se baja.

## Sin gradientes

Todo color es plano. No hay ni un gradiente en el diseño y no debería aparecer ninguno.
